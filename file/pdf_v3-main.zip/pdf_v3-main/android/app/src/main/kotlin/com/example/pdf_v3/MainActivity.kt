package com.example.pdf_v3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
