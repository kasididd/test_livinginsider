// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../API/crude.dart';
import '../API/func.dart';
import '../main.dart';
import '../professor/check_pdf.dart';
import '../professor/crude_csv.dart';
import '../professor/report.dart';
import '../professor/students.dart';
import '../provider/store.dart';
import '../student/check_pdf_student.dart';
import '../student/room_students.dart';
import '../student/select_professor.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List categories = [];
  String userClass = "";

  getData({required Store provider, required List categories}) async {
    await Users().userData(provider);

    CsvApi.getApi(owner: provider.userData['u_id']);
    check = false;
    List csv_cate =
        jsonDecode(await CsvApi.getApi(owner: provider.userData['u_id']));
    userClass = (provider.userData["class"]);

    provider.getCsvCate(
        data: csv_cate
            .map((e) =>
                CsvCateModel(u_id: e['u_id'], name: e['name'], time: e['time']))
            .toList());

    var dataUser = provider.userData;
    if (dataUser["class"] == "student") {
      pages = [
        {"page": const CheckStudentPDF(), "title": "Essay Submission"},
        // {"page": const NewTest(), "title": "Essay Submitsion"},

        // {
        //   "page": StudentsPDF(user: provider.userData['user'], category: ""),
        //   "title": "History"
        // },

        {"page": const RoomStudents(category: "", csv_id: ""), "title": "Room"},
        {"page": const ListProfessor(), "title": "proffessor"},
      ];
    }
    var res = await CsvManage().getAllApi(owner: provider.userData['u_id']);
    provider.getAllCsv(data: res);
  }

  bool student = false;
  int i = 0;
  List pages = [
    {"page": const Report(), "title": "Report"},
    {"page": const CheckPdf(), "title": "Assignments"},
    // {"page": const CheckHistory(), "title": "Information Management"},
    {"page": const CrudeCsv(), "title": "Errors Data"},
    {"page": const Students(), "title": "Students List"},
  ];
  bool check = true;

  String? category;
  String dropdonw = "L1";
  List listDropDown = [
    "L1",
    "Grammar",
    "Print",
    "Read comment",
    "Edit comment"
  ];
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (check) {
      getData(provider: provider, categories: categories);
    }
    return Scaffold(
        drawer: SafeArea(child: Drawer(child: drawerElement(context))),
        appBar: AppBar(
          centerTitle: true,
          title: pages[i]['title'] == "Assignments"
              ? const Text("")
              : Text(pages[i]['title']),
          actions: [
            if (pages[i]['title'] == "Report")
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SelectG(),
                        ));
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: provider.original
                        ? Theme.of(context).primaryColor.withOpacity(.1)
                        : Colors.white,
                  ),
                  child: const Text("Edit room")),
            if (pages[i]['title'] == "Assignments")
              Row(
                children: [
                  ElevatedButton(
                      onPressed: () {
                        provider.getOriginal(data: !provider.original);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: provider.original
                            ? Theme.of(context).primaryColor.withOpacity(.1)
                            : Colors.white,
                      ),
                      child: const Text("Read Original")),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: DropdownButton(
                      items: listDropDown
                          .map((e) => DropdownMenuItem(
                                value: e,
                                child: Text(e),
                              ))
                          .toList(),
                      value: dropdonw,
                      onChanged: (value) => setState(() {
                        dropdonw = value.toString();
                        switch (value) {
                          case "L1":
                            provider.getreadOnly(data: true);
                            provider.getOnSelect(data: false);
                            provider.getL1(data: true);
                            provider.getCheckGrammar(data: false);
                            break;
                          case "Grammar":
                            provider.getreadOnly(data: true);
                            provider.getOnSelect(data: false);
                            provider.getL1(data: false);
                            provider.getCheckGrammar(data: true);

                            break;
                          case "Print":
                            provider.getreadOnly(data: true);
                            provider.getOnSelect(data: true);
                            provider.getL1(data: false);
                            provider.getCheckGrammar(data: false);
                            break;
                          case "Read comment":
                            provider.getreadOnly(data: true);
                            provider.getOnSelect(data: false);
                            provider.getL1(data: false);
                            provider.getCheckGrammar(data: false);
                            break;
                          case "Edit comment":
                            provider.getreadOnly(data: false);
                            provider.getOnSelect(data: false);
                            provider.getL1(data: false);
                            provider.getCheckGrammar(data: false);
                            break;
                        }
                      }),
                    ),
                  ).animate().moveX(),
                  if (provider.onSelect)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: IconButton(
                          onPressed: () {
                            setState(() {
                              Func().createPdf(provider: provider);
                              // provider.onSelect = !provider.onSelect;
                            });
                          },
                          icon: Icon(
                            Icons.print,
                            color: Colors.grey.shade800,
                          )),
                    ).animate().moveX(),
                  if (!provider.readOnly)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18.0),
                      child: IconButton(
                          onPressed: () {
                            provider.getHaveText(data: false);
                            for (int i = 0; i < provider.comments.length; i++) {
                              if (provider.textOnChang[i]) {
                                PdfApi().commentInsert(
                                    comment: provider.comments[i].text,
                                    u_id: provider.u_id_comments[i]);
                              }
                            }
                            // print(
                            //     "provider.comments.length : ${provider.comments.length}\n provider.textOnChang.length : ${provider.textOnChang.length}\n provider.u_id_comments.length : ${provider.u_id_comments.length}");
                          },
                          icon: Icon(
                            Icons.save,
                            color: provider.haveText
                                ? Colors.amber
                                : Colors.grey.shade800,
                          )),
                    ).animate().moveX()
                ],
              )
          ],
        ),
        body: userClass.isEmpty
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : SafeArea(child: pages[i]['page']));
  }

// จัดการdrawer
  SingleChildScrollView drawerElement(BuildContext context) {
    Store provider = context.watch<Store>();
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 18.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Align(
                alignment: Alignment.center,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        onPressed: () => {
                              provider.getSizeFonst(
                                  data: provider.sizeFonts - 1),
                            },
                        child: const Icon(Icons.remove)),
                    Text('ขนาด Fonts ${provider.sizeFonts}'),
                    TextButton(
                        onPressed: () => {
                              provider.getSizeFonst(
                                  data: provider.sizeFonts + 1),
                            },
                        child: const Icon(Icons.add)),
                  ],
                ),
              ),
            ),
            for (int index = 0; index < pages.length; index++)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                width: double.infinity,
                child: TextButton(
                    onPressed: () => {
                          setState(() {
                            i = index;
                            if (pages[index]['title'] == "Assignments") {
                              setState(() {
                                categories = (provider.csvCate
                                    .map((e) =>
                                        e.name.substring(0, e.name.length - 4))
                                    .toList());
                              });
                            }
                          }),
                          Navigator.pop(context)
                        },
                    child: Container(
                      padding: const EdgeInsets.only(left: 10),
                      width: double.infinity,
                      child: Text(
                        pages[index]['title'],
                        textAlign: TextAlign.left,
                        style: const TextStyle(fontSize: 24),
                      ),
                    )),
              ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              width: double.infinity,
              child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent),
                  onPressed: () => {
                        Usehive().auth("logout", ""),
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MainPage()))
                      },
                  child: const Text(
                    "Logout",
                    style: TextStyle(fontSize: 24),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
