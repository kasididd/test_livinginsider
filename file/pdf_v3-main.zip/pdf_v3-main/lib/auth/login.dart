import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

import '../API/crude.dart';
import '../provider/store.dart';
import 'mainPage.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController user = TextEditingController(),
      password = TextEditingController(),
      name = TextEditingController(),
      stuID = TextEditingController(),
      cPassword = TextEditingController();
  bool register = false, loading = true;
  bool eys1 = false, eys2 = false, wrong = false, profressor = false;
  List listProfessor = [];
  String? professor;
  String uIdProfessor = "";
  getProfesor() async {
    listProfessor = await Users().getProfessor();
    print(listProfessor.map((e) => jsonDecode(e['data'])['name']));
    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (loading) {
      getProfesor();
    }
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              right: 20,
              top: 20,
              child: IconButton(
                  onPressed: () => showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          content: SingleChildScrollView(child: Text(howToUse)),
                        ),
                      ),
                  icon: Icon(Icons.question_mark))),
          const Positioned(
              right: 0,
              bottom: 20,
              child: Padding(
                padding: EdgeInsets.all(8.0),
                child: Text("version Full 1.2"),
              )),
          Center(
            child: SizedBox(
              width: 350,
              child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (register)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            const Text("Teacher ?"),
                            Switch(
                              value: profressor,
                              onChanged: (value) {
                                setState(() {
                                  profressor = value;
                                });
                              },
                            ),
                          ],
                        ).animate().fadeIn(),
                      TextFormField(
                        controller: user,
                        validator: (value) => value!.isEmpty ? "Email" : null,
                        decoration: const InputDecoration(label: Text("Email")),
                      ),
                      TextFormField(
                        obscureText: !eys1,
                        controller: password,
                        validator: (value) =>
                            value!.isEmpty ? "กรอกPassword" : null,
                        decoration: InputDecoration(
                            label: const Text("Password"),
                            suffixIcon: IconButton(
                                onPressed: () => setState(() {
                                      eys1 = !eys1;
                                    }),
                                icon: !eys1
                                    ? const Icon(Icons.visibility_off)
                                    : const Icon(Icons.visibility))),
                      ),
                      if (register)
                        Column(
                          children: [
                            TextFormField(
                              obscureText: !eys2,
                              controller: cPassword,
                              validator: (value) =>
                                  password.text != cPassword.text
                                      ? "Password not equal"
                                      : value!.isEmpty
                                          ? "confirm Password"
                                          : null,
                              decoration: InputDecoration(
                                  label: const Text("Confirm password"),
                                  suffixIcon: IconButton(
                                      onPressed: () => setState(() {
                                            eys2 = !eys2;
                                          }),
                                      icon: !eys2
                                          ? const Icon(Icons.visibility_off)
                                          : const Icon(Icons.visibility))),
                            ).animate().addEffect(const MoveEffect()),
                            TextFormField(
                              controller: name,
                              validator: (value) =>
                                  name.text.isEmpty ? "fill out" : null,
                              decoration: const InputDecoration(
                                label: Text("Full Name"),
                              ),
                            ).animate().addEffect(const MoveEffect()),
                            if (!profressor)
                              Column(
                                children: [
                                  TextFormField(
                                    controller: stuID,
                                    validator: (value) =>
                                        stuID.text.isEmpty ? "fill out" : null,
                                    decoration: const InputDecoration(
                                      label: Text("Student ID"),
                                    ),
                                  ).animate().addEffect(const MoveEffect()),
                                  DropdownButton(
                                    items: listProfessor
                                        .map((e) =>
                                            jsonDecode(e['data'])['name'])
                                        .toList()
                                        .map((e) => DropdownMenuItem(
                                            value: e, child: Text(e)))
                                        .toList(),
                                    value: professor,
                                    hint: const Text("Select professor"),
                                    onChanged: (value) => setState(() {
                                      professor = value.toString();
                                      uIdProfessor = listProfessor
                                          .firstWhere((element) =>
                                              jsonDecode(
                                                  element['data'])['name'] ==
                                              professor)['u_id']
                                          .toString();
                                    }),
                                  ).animate().addEffect(const MoveEffect()),
                                ],
                              ),
                          ],
                        ),
                      const SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextButton(
                                  onPressed: () => setState(() {
                                        register = !register;
                                      }),
                                  child: Text(register
                                      ? "Already have password ?"
                                      : "Did't have Password?")),
                              if (!register)
                                TextButton(
                                        onPressed: () => Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  const Forget(),
                                            )),
                                        child: const Text("For get password?"))
                                    .animate()
                                    .fadeIn(),
                            ],
                          ),
                          OutlinedButton(
                              onPressed: () async {
                                if (formKey.currentState!.validate()) {
                                  if (register) {
                                    if (professor != null && !profressor ||
                                        profressor && professor == null) {
                                      var res = await Users().register(
                                          professor: uIdProfessor,
                                          data:
                                              '{"name":"${name.text}","stuID":"${stuID.text}"}',
                                          user: user.text.trim(),
                                          password: password.text.trim(),
                                          clas: profressor
                                              ? "profressor"
                                              : "student");
                                      if (res == "sucessfully") {
                                        setState(() {
                                          register = !register;
                                          showSnack("Create ID success!");
                                        });
                                      } else {
                                        showSnack("same Username!!");
                                      }
                                    }
                                  } else {
                                    var res = await Users().login(
                                        user: user.text.trim(),
                                        password: password.text.trim());
                                    if (res != "Error") {
                                      await Usehive().auth(
                                          "login",
                                          jsonDecode(
                                                  res.toString().split("]")[0] +
                                                      "]")[0]['user']
                                              .toString());
                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const MyHomePage()));
                                    } else {
                                      showSnack(null);
                                    }
                                  }
                                } else {}
                              },
                              child: Row(
                                children: [
                                  const Icon(Icons.login),
                                  Text(register ? "Register" : "Login"),
                                ],
                              )),
                        ],
                      )
                    ],
                  )).animate().move(),
            ),
          ),
        ],
      ),
    );
  }

  showSnack(text) {
    text ??= "ไม่พบข้อมูล...";
    final snackBar = SnackBar(
      content: Text(text),
      action: SnackBarAction(
        label: 'Ok',
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
}

class Forget extends StatefulWidget {
  const Forget({super.key});

  @override
  State<Forget> createState() => _ForgetState();
}

class _ForgetState extends State<Forget> {
  TextEditingController email = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("forget password"),
      ),
      body: Center(
        child: SizedBox(
          width: 400,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            TextField(
                controller: email,
                decoration: const InputDecoration(label: Text("Email"))),
            const SizedBox(
              height: 20,
            ),
            OutlinedButton(
                onPressed: () async {
                  String token = Random().nextInt(1000000000).toString();
                  var res = await http.post(
                      Uri.parse(
                          "http://$config:8000/backend/change_password/token.php"),
                      body: {"email": email.text.trim(), "token": token});
                  print(res.body);
                  if (res.statusCode == 200 && res.body == "success") {
                    String toEmail = email.text;
                    String link =
                        "http://$config:8000/backend/change_password/?token=$token&email=${email.text}";
                    var res = await Users()
                        .sendResetPassword(email_receiver: toEmail, link: link);
                    print(res);
                  }
                },
                child: const Text("ส่งEmail"))
          ]),
        ),
      ),
    );
  }
}
