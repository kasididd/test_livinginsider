// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:hive_flutter/hive_flutter.dart';

class Store with ChangeNotifier {
  String? category;
  getCategory({required String data}) {
    category = data;
    notifyListeners();
  }

  List csv = [];
  getCsv({required List data}) {
    csv = data;
    notifyListeners();
  }

  List Allcsv = [];
  getAllCsv({required List data}) {
    Allcsv = data;
    notifyListeners();
  }

  List idCsv = [];
  getIdCsv({required List data}) {
    idCsv = data;
    notifyListeners();
  }

  List<CsvCateModel> csvCate = [];
  getCsvCate({required List<CsvCateModel> data}) {
    csvCate = data;
    notifyListeners();
  }

  List comments = <TextEditingController>[];
  getComments({required List data}) {
    comments = data;
    notifyListeners();
  }

  List u_id_comments = [];
  getU_id_cooments({required List data}) {
    u_id_comments = data;
    notifyListeners();
  }

  List select_print = [];
  getSelect_print({required List data}) {
    select_print = data;
    notifyListeners();
  }

  List textOnChang = [];
  getTextOnChang({required List data}) {
    textOnChang = data;
    notifyListeners();
  }

  List textPDF = [];
  getTextPDF({required List data}) {
    textPDF = data;
    notifyListeners();
  }

  bool readOnly = true;
  getreadOnly({required bool data}) {
    readOnly = data;
    notifyListeners();
  }

  bool checkGrammar = false;
  getCheckGrammar({required bool data}) {
    checkGrammar = data;
    notifyListeners();
  }

  bool l1 = true;
  getL1({required bool data}) {
    l1 = data;
    notifyListeners();
  }

  bool onSelect = false;
  getOnSelect({required bool data}) {
    onSelect = data;
    notifyListeners();
  }

  bool haveText = false;
  getHaveText({required bool data}) {
    haveText = data;
    notifyListeners();
  }

  bool original = false;
  getOriginal({required bool data}) {
    original = data;
    notifyListeners();
  }

  double sizeFonts = 16;
  getSizeFonst({required double data}) {
    sizeFonts = data;
    notifyListeners();
  }

  dynamic userData;
  dynamic userJson;
  getUser({required var data}) {
    userData = jsonDecode(data)[0];
    userJson = jsonDecode(userData['data']);
    notifyListeners();
  }
}

class Usehive {
  auth(String func, String user) async {
    await Hive.initFlutter();
    await Hive.openBox('myBox');
    var box = Hive.box('myBox');

    if (func == "login") {
      box.put('status', user);
      // var status = await box.get('status');
      // print('Name: $status');
    }
    if (func == "check") {
      var status = await box.get('status');
      if (status == null) {
        box.put('status', "logout");
      }
      // print(status);
      return await status ?? "";
    }
    if (func == "logout") {
      box.put('status', "logout");
      var status = await box.get('status');
      print('Name: $status');
    }
  }
}

class CsvCateModel {
  CsvCateModel({required this.u_id, required this.name, required this.time});
  final String u_id;
  final String name;
  final String time;
}
