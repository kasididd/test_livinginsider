import 'package:flutter/material.dart';
import 'package:pdf_v3/auth/login.dart';
import 'package:pdf_v3/auth/mainPage.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() {
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(
        create: (context) => Store(),
      )
    ],
    child: const MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        // showPerformanceOverlay: true,
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
          useMaterial3: true,
          textTheme: TextTheme(
            bodyLarge: const TextStyle(fontSize: 20),
            bodyMedium: TextStyle(fontSize: context.watch<Store>().sizeFonts),
            displayLarge: const TextStyle(fontSize: 20),
          ),
          primarySwatch: Colors.blue,
        ),
        home: const MainPage());
  }
}

class Test extends StatefulWidget {
  const Test({super.key});

  @override
  State<Test> createState() => _TestState();
}

class _TestState extends State<Test> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  String check = "_";
  setHive() async {
    String res = await Usehive().auth("check", "");
    if (res != "logout" && res.isNotEmpty) {
      setState(() {
        check = res;

        // check = "logout";
      });
    } else {
      setState(() {
        check = "logout";
      });
    }
    f = false;
  }

  bool f = true;
  @override
  void initState() {
    // setHive();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (f) setHive();

    return Scaffold(
      body: check == "logout"
          ? const Login()
          : check == "_" || context.watch<Store>().userData.toString().isEmpty
              ? const Scaffold(
                  body: Center(
                  child: CircularProgressIndicator(),
                ))
              : const MyHomePage(),
    );
  }
}

class TestPrint extends StatelessWidget {
  const TestPrint(this.title, {Key? key}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text(title)),
        body: PdfPreview(
          build: (format) => _generatePdf(format, title),
        ),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true);
    final font = await PdfGoogleFonts.nunitoExtraLight();

    pdf.addPage(
      pw.Page(
        pageFormat: format,
        build: (context) {
          return pw.Column(
            children: [
              pw.SizedBox(
                width: double.infinity,
                child: pw.FittedBox(
                  child: pw.Text(title, style: pw.TextStyle(font: font)),
                ),
              ),
              pw.SizedBox(height: 20),
              pw.Flexible(child: pw.FlutterLogo())
            ],
          );
        },
      ),
    );

    return pdf.save();
  }
}
