import 'dart:convert';
import 'package:pdf_v3/provider/store.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/professor/widget/csv_page.dart';
import 'package:provider/provider.dart';

class CrudeCsv extends StatefulWidget {
  const CrudeCsv({super.key});

  @override
  State<CrudeCsv> createState() => _CrudeCsvState();
}

class _CrudeCsvState extends State<CrudeCsv> {
  calbackApi(Store provider) async {
    var res = await CsvApi.getApi(owner: provider.userData['u_id']);
    if (res != "ไม่มีเน็ต") {
      csvFile = jsonDecode(res);
      provider.getAllCsv(
          data: await CsvManage().getAllApi(owner: provider.userData['u_id']));
      setState(() {
        getData = false;
      });
    }
  }

  List<int> csv = [];
  String? nameCsv;
  String? msg;
  // เช็คว่าเป็นTeacherหรือไม่
  bool isPro = true;
  // เก็บค่าว่ากำลังแก้ไขหรือไม่
  bool editOn = false;
  bool getData = true;
  // ตัวแปรเก็บค่าCsv
  List csvFile = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool windows = size.width > size.height;
    Store provider = context.watch<Store>();
    if (getData) {
      calbackApi(context.watch<Store>());
    }
    return Center(
      child: SizedBox(
        width: windows ? size.width / 2 : size.width,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'เลือกหัวข้อ',
                  style: TextStyle(fontSize: 24),
                ),
                isPro
                    ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        child: IconButton(
                          icon: Icon(editOn ? Icons.close : Icons.edit),
                          onPressed: () => setState(() {
                            editOn = !editOn;
                          }),
                        ),
                      )
                    : Text('')
              ],
            ),
            Expanded(
                child: Card(
              elevation: 8,
              child: ListView(
                children: [
                  for (int i = 0; i < csvFile.length; i++)
                    InkWell(
                      onTap: () async => editOn
                          ? {
                              await CsvApi.deleteApi(name: csvFile[i]['name']),
                              await CsvManage.deleteApi(
                                  owner: provider.userData['u_id'],
                                  name: csvFile[i]['name']),
                              calbackApi(provider)
                            }
                          : Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) =>
                                  CsvPage(data: csvFile[i]['name']),
                            )),
                      child: ListTile(
                        title: Text(csvFile[i]['name']),
                        trailing: Icon(
                          editOn ? Icons.delete : Icons.arrow_forward_ios,
                          color: editOn ? Colors.red : Colors.grey,
                        ),
                      ),
                    ),
                  editOn
                      ? IconButton(
                          onPressed: () async {
                            await pickCsv();
                            var res = await CsvApi.uploadCsv(
                                csv: csv,
                                name: nameCsv,
                                owner: provider.userData['u_id']);

                            if ("same!" == res) {
                              alert();
                            } else
                              print(res);
                            calbackApi(provider);
                          },
                          icon: Icon(Icons.add),
                        )
                      : Text('')
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }

  Future pickCsv() async {
    try {
      final pic = await FilePicker.platform
          .pickFiles(type: FileType.custom, allowedExtensions: ['csv']);
      print(pic!.files.first.extension);
      var res = pic.files.first.bytes;

      Uint8List? base64 = res;
      csv = pic.files.first.bytes as List<int>;
      nameCsv = pic.files.first.name;
      setState(() {
        msg = pic.names.toString();
      });
    } catch (e) {
      print(e);
    }
  }

// get API data
  getCate() async {
    final url = Uri.parse("http://$config/pdf/backend/php.php");
    try {
      var res = await http
          .post(url, body: {"action": "GET_ALL", "table": "csv_cate"});

      if (res.statusCode == 200) {
        print(res.body);
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  alert() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
          title:
              Text("แอดไฟล์:$nameCsv ไปแล้วหากต้องการแอดใหม่โปรดลบตัวเก่าออก")),
    );
  }
}
