// ignore_for_file: non_constant_identifier_names

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:pdf_v3/professor/widget/room.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

import 'room_csv.dart';

class Report extends StatefulWidget {
  const Report({super.key});

  @override
  State<Report> createState() => _ReportState();
}

class _ReportState extends State<Report> {
  List listContainer = [
    Container(
      color: Colors.red,
    ),
    Container(
      color: Colors.amber,
    ),
    Container(
      color: Colors.purple,
    ),
  ];
  List csvFile = [],
      recordBTN = [
        "Most frequent error words",
        // "suggestion ที่ใช้มากที่สุด",
        "Least frequent error words",
        "Errors type"
      ],
      recordData = [],
      roomAll = [];
  bool showRecords = true, callData = true;
  int selectRecord = 0;
  List csv_cate = [];
  String category = '';

  calbackApi({required Store provider}) async {
    roomAll = await Room().getAllRomm(user: provider.userData['user']);

    csv_cate =
        (jsonDecode(await CsvApi.getApi(owner: provider.userData['u_id'])));
    csv_cate = csv_cate.map((e) => e['name']).toList();
    print(csv_cate[0]);
    category = csv_cate[0];
    var res = await CsvApi.getApi(owner: provider.userData['u_id']);
    if (res != "ไม่มีเน็ต") {
      setState(() {
        csvFile = jsonDecode(res);
      });
    }

    loading = false;
  }

  bool loading = true;

  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    getRecord() async {
      var res = await CsvManage()
          .DESC(name_csv: category, owner: provider.userData['u_id']);
      recordData = await res;
      setState(() {
        recordData;
        callData = false;
      });
    }

    if (loading) {
      calbackApi(provider: provider);
    }
    if (callData) {
      getRecord();
    }
    return csvFile.isEmpty
        ? Center(
            child: loading
                ? const CircularProgressIndicator()
                : const Text("No data"))
        : Column(
            children: [
              Expanded(
                flex: showRecords ? 1 : 3,
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: 8,
                      horizontal: Utility().phone(context)
                          ? 8
                          : Utility().size(context).width / 6),
                  child: ListView.builder(
                    itemCount: roomAll.length,
                    itemBuilder: (context, index) => Card(
                        clipBehavior: Clip.antiAlias,
                        elevation: 2,
                        child: InkWell(
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => RoomCsv(
                                        roomData: roomAll[index],
                                      ))),
                          child: ListTile(
                            leading: Text(
                              roomAll[index]['room_name']
                                  .toString()
                                  .split(".")[0],
                              style: const TextStyle(fontSize: 24),
                            ),
                          ),
                        )),
                  ),
                ),
              ),
              Expanded(
                  flex: showRecords ? 3 : 1,
                  child: Card(
                    child: SizedBox(
                      width: Utility().phone(context)
                          ? double.infinity
                          : Utility().size(context).width / 1.5,
                      child: Column(
                        children: [
                          SizedBox(
                            height: !showRecords ? 50 : 200,
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TextButton(
                                      onPressed: () {
                                        setState(() {
                                          showRecords = !showRecords;
                                        });
                                      },
                                      child: Column(
                                        children: [
                                          const Text(
                                            "Record",
                                            style: TextStyle(fontSize: 24),
                                          ),
                                          if (showRecords)
                                            const Icon(
                                                Icons.arrow_drop_down_rounded)
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 20,
                                    ),
                                    DropdownButton(
                                      items: csv_cate
                                          .map((e) => DropdownMenuItem(
                                              value: e, child: Text(e)))
                                          .toList(),
                                      value: category,
                                      hint: const Text("Category"),
                                      onChanged: (value) => setState(() {
                                        category = value.toString();
                                        print("categories $category");
                                      }),
                                    ),
                                  ],
                                ),
                                if (showRecords)
                                  Expanded(
                                      child: buttonSelect(provider: provider)),
                              ],
                            ),
                          ),
                          if (showRecords)
                            Expanded(
                                child: SizedBox(
                                    child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: const [
                                      Expanded(
                                          child: Text(
                                        "List",
                                        // ประโยค
                                        // textAlign: TextAlign.center,
                                      )),
                                      SizedBox(
                                          child: Text("Numbers of errors")),
                                    ],
                                  ),
                                ),
                                Expanded(
                                    // list สำหรับใส่ข้อมูลRecord
                                    child: recordData.isEmpty
                                        ? const Center(
                                            child: Text("No data"),
                                          )
                                        : ListView.builder(
                                            itemCount: recordData.length,
                                            itemBuilder: (context, index) =>
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Expanded(
                                                        child: Text(selectRecord ==
                                                                2
                                                            ? "errors type : " +
                                                                recordData[
                                                                        index]
                                                                    ['name']
                                                            : recordData[index][
                                                                'Expressions']),
                                                      ),
                                                      SizedBox(
                                                        child: Text(selectRecord ==
                                                                2
                                                            ? recordData[index]
                                                                ['numbers']
                                                            : recordData[index]
                                                                    ['record_e']
                                                                .toString()),
                                                      )
                                                    ],
                                                  ),
                                                )))
                              ],
                            )))
                        ],
                      ),
                    ),
                  ))
            ],
          );
  }

  SizedBox buttonSelect({required Store provider}) {
    bool phon = MediaQuery.of(context).size.width < 550;
    return SizedBox(
      child: phon
          ? Column(
              children: [
                for (int i = 0; i < recordBTN.length; i++)
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: TextButton(
                          style: TextButton.styleFrom(
                              elevation: selectRecord == i ? 8 : 0,
                              shadowColor: Colors.red.shade300,
                              backgroundColor: Colors.purple.shade100),
                          onPressed: () async {
                            // var res =
                            //     i == 0 ? CsvManage().DESC() : CsvManage().ASC();
                            var res = [];
                            switch (i) {
                              case 0:
                                res = await CsvManage().DESC(
                                    name_csv: category,
                                    owner: provider.userData['u_id']);
                                break;

                              case 1:
                                res = await CsvManage().ASC(
                                    name_csv: category,
                                    owner: provider.userData['u_id']);
                                break;

                              case 2:
                                res = await CsvManage().getRecordType(
                                    user_id: provider.userData['u_id']);
                                break;
                            }
                            recordData = res;
                            setState(() {
                              recordData;
                              selectRecord = i;
                            });
                          },
                          child: Text(
                            recordBTN[i],
                            style: const TextStyle(color: Colors.black),
                          )).animate().fade(),
                    ),
                  ),
              ],
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (int i = 0; i < recordBTN.length; i++)
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: TextButton(
                          style: TextButton.styleFrom(
                              elevation: selectRecord == i ? 8 : 0,
                              shadowColor: Colors.red.shade300,
                              backgroundColor: Colors.purple.shade100),
                          onPressed: () async {
                            var res = [];
                            switch (i) {
                              case 0:
                                res = await CsvManage().DESC(
                                    name_csv: category,
                                    owner: provider.userData['u_id']);
                                break;

                              case 1:
                                res = await CsvManage().ASC(
                                    name_csv: category,
                                    owner: provider.userData['u_id']);
                                break;

                              case 2:
                                res = await CsvManage().getRecordType(
                                    user_id: provider.userData['u_id']);
                                break;
                            }
                            recordData = res;
                            setState(() {
                              recordData;
                              selectRecord = i;
                            });
                          },
                          child: Text(
                            recordBTN[i],
                            style: const TextStyle(color: Colors.black),
                          )).animate().fade(),
                    ),
                  ),
              ],
            ),
    );
  }
}

class SelectG extends StatefulWidget {
  const SelectG({super.key});
  @override
  State<SelectG> createState() => _SelectGState();
}

class _SelectGState extends State<SelectG> {
  @override
  void dispose() {
    nameController.map((e) => e..dispose()).toList();
    super.dispose();
  }

  List roomData = [],
      changName = [],
      nameController = <TextEditingController>[];
  getRoomData(Store provider) async {
    var res = await Room().getAllRomm(user: provider.userData['user']);
    res == "empty" ? itEmpty = true : roomData = res;
    setState(() {
      changName = List.generate(roomData.length, (index) => false);
      nameController =
          List.generate(roomData.length, (index) => TextEditingController());
    });
  }

  bool edit = false, itEmpty = false;
  @override
  Widget build(BuildContext context) {
    addRoom(context, Store provider) async {
      await showDialog(
          context: context,
          builder: (context) {
            final GlobalKey<FormState> formKey = GlobalKey<FormState>();
            TextEditingController name = TextEditingController();
            void validateAndSave() async {
              final FormState? form = formKey.currentState;
              if (form!.validate()) {
                {
                  await Room.Insert(
                      // TODO: csv_id
                      csv_id: "0",
                      user: provider.userData['user'],
                      name: name.text.trim());
                  await getRoomData(provider);
                  Navigator.pop(context);
                }
              } else {
                print('Form is invalid');
              }
            }

            return AlertDialog(
              title: const Text("add room"),
              content: SizedBox(
                width: 300,
                height: 200,
                child: Form(
                  key: formKey,
                  child: Column(
                    children: [
                      Expanded(
                          child: TextFormField(
                        validator: (value) =>
                            value!.isEmpty ? "Please fill in" : null,
                        decoration:
                            const InputDecoration(label: Text("Room name")),
                        controller: name,
                      )),
                      OutlinedButton(
                          onPressed: () async {
                            validateAndSave();
                          },
                          child: const Text("accept"))
                    ],
                  ),
                ),
              ),
            );
          });
    }

    Store provider = context.watch<Store>();

    if (roomData.isEmpty && !itEmpty) {
      getRoomData(provider);
    }
    return Scaffold(
      appBar: AppBar(
        // TODO: select room

        title: const Text("Select room"),
        actions: [
          Row(
            children: [
              changName.where((element) => element).toList().length > 0
                  ? IconButton(
                      onPressed: () async {
                        for (int i = 0; i < changName.length; i++) {
                          if (changName[i]) {
                            await Room.Update(
                                u_id: roomData[i]['u_id'],
                                name: nameController[i].text.trim());
                          }
                        }
                        edit = !edit;
                        await getRoomData(provider);
                        for (int i = 0; i < changName.length; i++) {
                          setState(
                            () => changName[i] = false,
                          );
                        }
                      },
                      icon: const Icon(Icons.save))
                  : IconButton(
                      onPressed: () async => {
                            addRoom(context, provider),
                          },
                      icon: const Icon(Icons.add)),
              IconButton(
                  onPressed: () async => setState(() => {
                        edit = !edit,
                        for (int i = 0; i < changName.length; i++)
                          {changName[i] = false}
                      }),
                  icon: Icon(edit ? Icons.close : Icons.edit)),
            ],
          )
        ],
      ),
      body: roomData.isEmpty
          ? Center(
              child: !itEmpty
                  ? const CircularProgressIndicator()
                  : const Text("no data"),
            )
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 4),
              child: ListView.builder(
                itemCount: roomData.length,
                itemBuilder: (context, index) => Material(
                  child: Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 2,
                      child: InkWell(
                        onTap: edit
                            ? null
                            : () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ListStudents(
                                      roomID: roomData[index]['u_id'],
                                      u_id: roomData[index]['u_id'],
                                      // TODO:Category
                                      category: "widget.category"),
                                )),
                        child: ListTile(
                          leading: changName[index] && edit
                              ? const Icon(Icons.arrow_forward_ios)
                              : Text(
                                  roomData[index]['room_name'],
                                  style: const TextStyle(fontSize: 17),
                                ),
                          trailing: !edit
                              ? const Icon(Icons.arrow_forward_ios)
                                  .animate()
                                  .fade()
                              : Wrap(
                                  alignment: WrapAlignment.end,
                                  children: [
                                    if (changName[index] && edit)
                                      SizedBox(
                                        width: 200,
                                        child: TextField(
                                          controller: nameController[index],
                                        ),
                                      ).animate().fade(),
                                    IconButton(
                                        onPressed: () {
                                          setState(() {
                                            nameController[index] =
                                                TextEditingController(
                                                    text: roomData[index]
                                                        ['room_name']);
                                            changName[index] =
                                                !changName[index];
                                          });
                                        },
                                        icon: Icon(changName[index]
                                            ? Icons.close
                                            : Icons.edit)),
                                    IconButton(
                                        onPressed: () async {
                                          await showDialog(
                                            context: context,
                                            builder: (context) => AlertDialog(
                                              title: const Text(
                                                  "Confirm delete room?"),
                                              content: Text(
                                                  roomData[index]['room_name']),
                                              actions: [
                                                OutlinedButton(
                                                    onPressed: () async => {
                                                          await Room.delete(
                                                              u_id: roomData[
                                                                      index]
                                                                  ['u_id']),
                                                          await getRoomData(
                                                              provider),
                                                          Navigator.pop(context)
                                                        },
                                                    child:
                                                        const Text("accept")),
                                                OutlinedButton(
                                                    onPressed: () =>
                                                        Navigator.pop(context),
                                                    child:
                                                        const Text("cancel")),
                                              ],
                                            ),
                                          );
                                        },
                                        icon: const Icon(
                                          Icons.delete,
                                          color: Colors.red,
                                        )),
                                  ],
                                ).animate().fade(),
                        ),
                      )),
                ),
              ),
            ),
    );
  }
}
