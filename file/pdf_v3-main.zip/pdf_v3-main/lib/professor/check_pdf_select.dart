// ignore_for_file: non_constant_identifier_names

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:pdf_v3/API/check_grammar.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

import '../API/func.dart';

class CheckPdfSelect extends StatefulWidget {
  const CheckPdfSelect(
      {super.key,
      required this.user,
      required this.roomID,
      required this.name,
      required this.category});
  final String user;
  final String name;
  final String roomID;
  final String category;
  @override
  State<CheckPdfSelect> createState() => _CheckPdfSelectState();
}

class _CheckPdfSelectState extends State<CheckPdfSelect> {
  // ข้อความในการแจ้งเตือนต่างๆ
  String? pdf;
  List pdfGet = [],
      pdfOriginal = [],
      pdfOwner = [],
      correct = [],
      commentController = <TextEditingController>[],
      textOnChange = [],
      prevComments = [],
      select = [],
      allCsv = [],
      getAllData = [];
  bool getting = true;
  getPdf({required Store provider}) async {
    allCsv = provider.Allcsv;
    var dataGet = await PdfApi().getPdfByRoomID(
        user: widget.user, category: widget.category, roomID: widget.roomID);
    List res = [];
    print("raww Data $dataGet");
    if (dataGet != "empty") {
      res = jsonDecode(dataGet);
      res = (jsonDecode(dataGet)
          .where((e) => e['RawSuggest'].toString() != "0")
          .toList());
      print("res $res");

      if (res.isEmpty) {
        itEmpty = true;
        setState(() {});
        return;
      }
    } else {
      itEmpty = true;
      setState(() {});
      return;
    }
    List test = res;

    List u_id = [];
    int io = 0;
    for (int i = 0; i < test.length; i++) {
      bool isNot0 = test[i]["RawSuggest"] != "0";
      if (isNot0) {
        var st8 = jsonDecode(test[i]['RawSuggest'])['data'];
        if (st8.toString()[0] == "[") {
          String text = st8.toString();
          List d = (text.substring(1, text.length - 1).split(","));
          List<int> eUtf8 = [];
          for (String a in d) {
            eUtf8.add(int.parse(a));
          }
          List s = jsonDecode(utf8.decode(eUtf8));
          String f =
              s.map((e) => (e['raw']).toString().trim()).toList().join("\n");
          pdfGet.add(f);
          // pdfOriginal.add(utf8.decoder(test[i]['text']));
          List<int> ax = [];
          List pa = test[i]['text']
              .toString()
              .substring(1, test[i]['text'].length - 1)
              .split(',')
              .toList();
          pa.map((e) => ax.add(int.parse(e))).toList();
          pdfOriginal.add(utf8.decode(ax));
          pdfOwner.add(test[i]['time']);
          correct.add(test[i]['correct']);
          u_id.add(test[i]['u_id']);
          prevComments.add(test[i]['comment']);
          getAllData.add(test[i]);
          if (test[i]['comment'].toString().trim().isNotEmpty) {
            commentController
                .add(TextEditingController(text: test[i]['comment']));
          } else {
            commentController.add(TextEditingController());
          }
        }
      }
      io++;
    }
    if (io == test.length) {
      provider.getU_id_cooments(data: u_id);
      provider.getComments(data: commentController);
      textOnChange = List.generate(u_id.length, (index) => false);
      select = List.generate(u_id.length, (index) => false);
      provider.getTextPDF(data: pdfGet);
      pdfGet;
      if (pdfGet.isEmpty) itEmpty = true;
      getting = false;
      if (!getting) setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
  }

  bool itEmpty = false;
  int openDetail = -1;
  String dropdonw = "L1";
  List listDropDown = [
    "L1",
    "Grammar",
    "Print",
    "Read comment",
    "Edit comment"
  ];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Store provider = context.watch<Store>();
    bool windows = size.width > size.height;

    if (getting && !itEmpty) {
      getPdf(provider: provider);
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name),
        actions: [
          Row(
            children: [
              ElevatedButton(
                  onPressed: () {
                    provider.getOriginal(data: !provider.original);
                  },
                  child: Text("Read Original"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: provider.original
                        ? Theme.of(context).primaryColor.withOpacity(.1)
                        : Colors.white,
                  )),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: DropdownButton(
                  items: listDropDown
                      .map((e) => DropdownMenuItem(
                            child: Text(e),
                            value: e,
                          ))
                      .toList(),
                  value: dropdonw,
                  onChanged: (value) => setState(() {
                    dropdonw = value.toString();
                    switch (value) {
                      case "L1":
                        provider.getreadOnly(data: true);
                        provider.getOnSelect(data: false);
                        provider.getL1(data: true);
                        provider.getCheckGrammar(data: false);
                        break;
                      case "Grammar":
                        provider.getreadOnly(data: true);
                        provider.getOnSelect(data: false);
                        provider.getL1(data: false);
                        provider.getCheckGrammar(data: true);

                        print("Grammar");
                        break;
                      case "Print":
                        provider.getreadOnly(data: true);
                        provider.getOnSelect(data: true);
                        provider.getL1(data: false);
                        provider.getCheckGrammar(data: false);
                        print("Print");
                        break;
                      case "Read comment":
                        provider.getreadOnly(data: true);
                        provider.getOnSelect(data: false);
                        provider.getL1(data: false);
                        provider.getCheckGrammar(data: false);
                        print("Comment");
                        break;
                      case "Edit comment":
                        provider.getreadOnly(data: false);
                        provider.getOnSelect(data: false);
                        provider.getL1(data: false);
                        provider.getCheckGrammar(data: false);
                        print("Comment");
                        break;
                    }
                  }),
                ),
              ).animate().moveX(),
              if (provider.onSelect)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: IconButton(
                      onPressed: () {
                        setState(() {
                          Func().createPdf(provider: provider);
                          // provider.onSelect = !provider.onSelect;
                        });
                      },
                      icon: Icon(
                        Icons.print,
                        color: Colors.grey.shade800,
                      )),
                ).animate().moveX(),
              // Padding(
              //   padding: const EdgeInsets.symmetric(horizontal: 8.0),
              //   child: IconButton(
              //       onPressed: () {
              //         provider.getreadOnly(data: true);
              //       },
              //       icon: Icon(
              //         Icons.read_more,
              //         color: Colors.grey.shade800,
              //       )),
              // ).animate().moveX(),
              if (!provider.readOnly)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18.0),
                  child: IconButton(
                      onPressed: () {
                        provider.getHaveText(data: false);
                        for (int i = 0; i < provider.comments.length; i++) {
                          if (provider.textOnChang[i]) {
                            PdfApi().commentInsert(
                                comment: provider.comments[i].text,
                                u_id: provider.u_id_comments[i]);
                          }
                        }
                        // print(
                        //     "provider.comments.length : ${provider.comments.length}\n provider.textOnChang.length : ${provider.textOnChang.length}\n provider.u_id_comments.length : ${provider.u_id_comments.length}");
                      },
                      icon: Icon(
                        Icons.save,
                        color: provider.haveText
                            ? Colors.amber
                            : Colors.grey.shade800,
                      )),
                ).animate().moveX()
            ],
          )
        ],
      ),
      body: getting
          ? Center(
              child: itEmpty
                  ? Text("No data..")
                  : const CircularProgressIndicator(),
            )
          : Center(child: haveData(windows, size, provider)),
    );
  }

  SizedBox haveData(bool windows, Size size, Store provider) {
    return SizedBox(
      width: windows ? size.width / 2 : size.width,
      child: Column(
        children: [
          Expanded(
              flex: 5,
              child: SizedBox(
                width: size.width,
                child: Card(
                    child: pdfGet.isNotEmpty && select.length == pdfGet.length
                        ? ListView.builder(
                            itemCount: pdfGet.length,
                            itemBuilder: (context, i) => Column(
                              children: [
                                dataShow(i, provider, context),
                                SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: Text(
                                        provider.l1
                                            ? "L1 use"
                                            : provider.checkGrammar
                                                ? "grammar"
                                                : provider.readOnly
                                                    ? "view comment"
                                                    : "add comment",
                                        style: const TextStyle(
                                            color: Colors.green),
                                        textAlign: TextAlign.end,
                                      ),
                                    )),
                                if (openDetail == i)
                                  ShowDetail(
                                      idCsv: getAllData[i]['id_csv']
                                          .toString()
                                          .substring(
                                              1,
                                              getAllData[i]['id_csv']
                                                      .toString()
                                                      .length -
                                                  1)
                                          .split(","),
                                      allCsv: allCsv,
                                      text: pdfGet[i].toString()),
                                Container(
                                  color: Colors.red.shade200,
                                  width: double.infinity,
                                  height: 2,
                                )
                              ],
                            ),
                          )
                        : const Text('')),
              ))
        ],
      ),
    );
  }

  Stack dataShow(int i, Store provider, BuildContext context) {
    return Stack(
      children: [
        Material(
          color: select[i] && provider.onSelect
              ? const Color.fromARGB(167, 250, 238, 127)
              : Colors.transparent,
          child: InkWell(
            onTap: provider.l1
                ? () {
                    setState(() {
                      openDetail = i;
                    });
                  }
                : provider.checkGrammar
                    ? () {
                        String checkTextDecode = pdfGet[i].toString();
                        int start = 0, end = 0, j = 0;
                        List deBrucked = [], result = [];
                        for (j; j < checkTextDecode.length; j++) {
                          if (checkTextDecode[j] == "[") {
                            start = j;
                          }
                          if (checkTextDecode[j] == "]") {
                            end = j;
                            for (int o = start; o <= end; o++) {
                              deBrucked.add(o);
                            }
                          }
                        }
                        for (int p = 0; p < checkTextDecode.length; p++) {
                          if (deBrucked
                              .where((element) => element == p)
                              .toList()
                              .isEmpty) {
                            result.add(checkTextDecode[p]);
                          }
                        }
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  CheckGrammar(data: result.join().trim()),
                            ));
                      }
                    : () async {
                        provider.onSelect
                            ? setState(() {
                                select[i] = !select[i];
                                provider.getSelect_print(data: select);
                              })
                            : await showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text("Comments"),
                                  content: TextField(
                                    enabled: !provider.readOnly,
                                    autofocus: true,
                                    onChanged: (value) {
                                      provider.getComments(
                                          data: commentController);
                                      if (provider.comments.isNotEmpty) {
                                        provider.comments.map((e) {
                                          if (e.text.length > 0) {
                                            provider.getHaveText(data: true);
                                            return e.text;
                                          }
                                        }).toList();
                                      }
                                      textOnChange[i] = true;
                                      provider.getTextOnChang(
                                          data: textOnChange);
                                    },
                                    controller: commentController[i],
                                    decoration: const InputDecoration(
                                        border: InputBorder.none),
                                    maxLines: 9,
                                    maxLength: 300,
                                  ),
                                ),
                              );
                      },
            child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        commentController[i]
                                    .text
                                    .toString()
                                    .trim()
                                    .isNotEmpty &&
                                prevComments[i] ==
                                    commentController[i].text.toString().trim()
                            ? const Icon(
                                Icons.check,
                                color: Colors.green,
                              )
                            : const SizedBox(),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20.0),
                          child: Text(
                            "Draft:${(i + 1)} | ID time:${provider.u_id_comments[i]} | time: ${pdfOwner[i]}",
                          ),
                        ),
                        Text(
                          commentController[i].text.length > 0 &&
                                  provider.haveText &&
                                  prevComments[i] !=
                                      commentController[i]
                                          .text
                                          .toString()
                                          .trim()
                              ? "..."
                              : "",
                          style: const TextStyle(
                              fontSize: 24, fontWeight: FontWeight.bold),
                        ).animate().shake()
                      ],
                    ),
                    Text(provider.original
                        ?
                        // oak
                        pdfGet[i].toString()
                        : pdfOriginal[i].toString()),
                  ],
                )),
          ),
        ),
        Positioned(
            right: 2,
            top: 2,
            child: ElevatedButton(
                onPressed: () async {
                  await PdfApi().correctUpdate(
                      correct: correct[i] == "1" ? "0" : "1",
                      u_id: provider.u_id_comments[i]);
                  setState(() {});
                  correct[i] = correct[i] == "1" ? "0" : "1";
                },
                child: Row(
                  children: [
                    Text("Correct"),
                    Checkbox(
                      value: correct[i] == "1" ? true : false,
                      onChanged: (value) async {
                        await PdfApi().correctUpdate(
                            correct: correct[i] == "1" ? "0" : "1",
                            u_id: provider.u_id_comments[i]);
                        setState(() {});
                        correct[i] = correct[i] == "1" ? "0" : "1";
                      },
                    )
                  ],
                )))
      ],
    );
  }
}

class ShowDetail extends StatelessWidget {
  ShowDetail(
      {super.key,
      required this.text,
      required this.allCsv,
      required this.idCsv});
  final String text;
  final List allCsv;
  final List idCsv;
  List data = [];
  getFinde() async {
    // for (String o in idCsv) {
    //   for (dynamic n in allCsv) {
    //     if ("5298" == n['u_id'].toString()) {
    //       data.add(n);
    //       print(n);
    //     }
    //   }
    // }
    // print(data);
    for (String c in idCsv) {
      data.add(allCsv
          .firstWhere((element) => element['u_id'].toString() == c.trim()));
    }
  }

  @override
  Widget build(BuildContext context) {
    getFinde();
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (dynamic d in data)
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${d['Expressions']} | errors type: ${d['Error type']}",
                      style: TextStyle(color: Colors.red),
                    ),
                    Text(
                      "sug1 : ${d['Suggestion1']}",
                      style: const TextStyle(color: Colors.amber),
                    ),
                    if (d['Suggestion2'].isNotEmpty)
                      Text(
                        "sug1 : ${d['Suggestion2']}",
                        style: const TextStyle(color: Colors.amber),
                      ),
                    // Container(
                    //   color: Colors.amber,
                    //   height: 2,
                    //   width: double.infinity,
                    // )
                  ],
                ),
              ),
            )
        ],
      ),
    );
  }
}
