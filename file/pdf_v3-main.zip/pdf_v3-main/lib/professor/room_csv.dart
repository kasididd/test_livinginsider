// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf_v3/professor/report.dart';
import 'package:provider/provider.dart';

import '../API/crude.dart';
import '../API/func.dart';
import '../provider/store.dart';
import 'widget/room.dart';

class RoomCsv extends StatefulWidget {
  const RoomCsv({super.key, required this.roomData});
  final dynamic roomData;
  @override
  State<RoomCsv> createState() => _RoomCsvState();
}

class _RoomCsvState extends State<RoomCsv> {
  void getData({required Store provider}) async {
    csvFile = jsonDecode(await CsvApi.getApi(owner: provider.userData['u_id']));
    loading = false;
    setState(() {});
  }

  List csvFile = [];
  bool loading = true;
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (loading) {
      getData(provider: provider);
    }
    return Scaffold(
      appBar: AppBar(),
      body: csvFile.isEmpty
          ? Center(
              child: loading
                  ? const CircularProgressIndicator()
                  : const Text("No data"))
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 6),
              child: ListView.builder(
                itemCount: csvFile.length,
                itemBuilder: (context, index) => Card(
                    clipBehavior: Clip.antiAlias,
                    elevation: 2,
                    child: InkWell(
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ListStudents(
                                roomID: widget.roomData['u_id'],
                                u_id: widget.roomData['u_id'].toString(),
                                category: csvFile[index]['name']
                                    .toString()
                                    .split(".")[0]),
                          )),
                      child: ListTile(
                        leading: Text(
                          csvFile[index]['name'].toString().split(".")[0],
                          style: const TextStyle(fontSize: 24),
                        ),
                      ),
                    )),
              ),
            ),
    );
  }
}
