// ignore_for_file: non_constant_identifier_names

import 'dart:async';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:pdf_v3/API/check_grammar.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

class CheckPdf extends StatefulWidget {
  const CheckPdf({super.key});
  @override
  State<CheckPdf> createState() => _CheckPdfState();
}

class _CheckPdfState extends State<CheckPdf> {
  // ข้อความในการแจ้งเตือนต่างๆ
  String msg = "";
  String? pdf;
  List pdfGet = [],
      pdfOriginal = [],
      pdfOwner = [],
      correct = [],
      commentController = <TextEditingController>[],
      textOnChange = [],
      prevComments = [],
      select = [],
      allCsv = [],
      getAllData = [];
  bool getting = true;
  getPdf(
      {required Store provider,
      required List selectUser,
      required List room_id}) async {
    allCsv = provider.Allcsv;
    List data = [];
    List test = [];
    for (String user in selectUser) {
      for (String room in room_id) {
        List a = await PdfApi().DESC(user: user, room_id: room);
        if (a.isNotEmpty) {
          data += a;
        }
      }
    }
    test = data;
    List u_id = [];
    int io = 0;
    for (int i = 0; i < test.length; i++) {
      bool isNot0 = test[i]["RawSuggest"] != "0";
      if (isNot0) {
        var st8 = jsonDecode(test[i]['RawSuggest'])['data'];
        if (st8.toString()[0] == "[") {
          String text = st8.toString();
          List d = (text.substring(1, text.length - 1).split(","));
          List<int> eUtf8 = [];
          for (String a in d) {
            eUtf8.add(int.parse(a));
          }
          List s = jsonDecode(utf8.decode(eUtf8));
          String f =
              s.map((e) => (e['raw']).toString().trim()).toList().join("\n");
          pdfGet.add(f);
          // pdfOriginal.add(utf8.decoder(test[i]['text']));
          List<int> ax = [];
          List pa = test[i]['text']
              .toString()
              .substring(1, test[i]['text'].length - 1)
              .split(',')
              .toList();
          pa.map((e) => ax.add(int.parse(e))).toList();
          pdfOriginal.add(utf8.decode(ax));
          pdfOwner.add(test[i]['user']);
          correct.add(test[i]['correct']);
          u_id.add(test[i]['u_id']);
          prevComments.add(test[i]['comment']);
          getAllData.add(test[i]);
          if (test[i]['comment'].toString().trim().isNotEmpty) {
            commentController
                .add(TextEditingController(text: test[i]['comment']));
          } else {
            commentController.add(TextEditingController());
          }
        }
      }
      io++;
    }
    if (io == test.length) {
      provider.getU_id_cooments(data: u_id);
      provider.getComments(data: commentController);
      textOnChange = List.generate(u_id.length, (index) => false);
      select = List.generate(u_id.length, (index) => false);
      provider.getTextPDF(data: pdfGet);
      pdfGet;
      if (pdfGet.isEmpty) itEmpty = true;
      getting = false;
      if (!getting) setState(() {});
    }
  }

  getUsers({required Store provider}) async {
    List user = await Users().getStudents(provider: provider);
    user = user.map((e) => e['user']).toList();
    List roomID = await Room().getAllRomm(user: provider.userData['user']);
    roomID = roomID.map((e) => e['u_id']).toList();
    print("user: $user");
    print("room_id ${roomID + user}");
    getPdf(provider: provider, selectUser: user, room_id: roomID);
    setState(() {
      getting = false;
    });
  }

  bool itEmpty = false;
  int openDetail = -1;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Store provider = context.watch<Store>();
    bool windows = size.width > size.height;

    if (getting) {
      // getPdf(provider: provider);
      getUsers(provider: provider);
    }
    return Center(
      child: getting
          ? const CircularProgressIndicator()
          : itEmpty
              ? Center(
                  child: Text("No data.."),
                )
              : haveData(windows, size, provider),
    );
  }

  SizedBox haveData(bool windows, Size size, Store provider) {
    return SizedBox(
      width: windows ? size.width / 2 : size.width,
      child: Column(
        children: [
          Expanded(
              flex: 5,
              child: SizedBox(
                width: size.width,
                child: Card(
                    child: pdfGet.isNotEmpty && select.length == pdfGet.length
                        ? ListView.builder(
                            itemCount: pdfGet.length,
                            itemBuilder: (context, i) => Column(
                              children: [
                                Stack(
                                  children: [
                                    Material(
                                      color: select[i] && provider.onSelect
                                          ? const Color.fromARGB(
                                              167, 250, 238, 127)
                                          : Colors.transparent,
                                      child: InkWell(
                                        onTap: provider.l1
                                            ? () {
                                                setState(() {
                                                  openDetail = i;
                                                });
                                              }
                                            : provider.checkGrammar
                                                ? () {
                                                    String checkTextDecode =
                                                        pdfGet[i].toString();
                                                    int start = 0,
                                                        end = 0,
                                                        j = 0;
                                                    List deBrucked = [],
                                                        result = [];
                                                    for (j;
                                                        j <
                                                            checkTextDecode
                                                                .length;
                                                        j++) {
                                                      if (checkTextDecode[j] ==
                                                          "[") {
                                                        start = j;
                                                      }
                                                      if (checkTextDecode[j] ==
                                                          "]") {
                                                        end = j;
                                                        for (int o = start;
                                                            o <= end;
                                                            o++) {
                                                          deBrucked.add(o);
                                                        }
                                                      }
                                                    }
                                                    for (int p = 0;
                                                        p <
                                                            checkTextDecode
                                                                .length;
                                                        p++) {
                                                      if (deBrucked
                                                          .where((element) =>
                                                              element == p)
                                                          .toList()
                                                          .isEmpty) {
                                                        result.add(
                                                            checkTextDecode[p]);
                                                      }
                                                    }
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              CheckGrammar(
                                                                  data: result
                                                                      .join()
                                                                      .trim()),
                                                        ));
                                                  }
                                                : () async {
                                                    provider.onSelect
                                                        ? setState(() {
                                                            select[i] =
                                                                !select[i];
                                                            provider
                                                                .getSelect_print(
                                                                    data:
                                                                        select);
                                                          })
                                                        : await showDialog(
                                                            context: context,
                                                            builder:
                                                                (context) =>
                                                                    AlertDialog(
                                                              title: const Text(
                                                                  "Comments"),
                                                              content:
                                                                  TextField(
                                                                enabled: !provider
                                                                    .readOnly,
                                                                autofocus: true,
                                                                onChanged:
                                                                    (value) {
                                                                  provider.getComments(
                                                                      data:
                                                                          commentController);
                                                                  if (provider
                                                                      .comments
                                                                      .isNotEmpty) {
                                                                    provider
                                                                        .comments
                                                                        .map(
                                                                            (e) {
                                                                      if (e.text
                                                                              .length >
                                                                          0) {
                                                                        provider.getHaveText(
                                                                            data:
                                                                                true);
                                                                        return e
                                                                            .text;
                                                                      }
                                                                    }).toList();
                                                                  }
                                                                  textOnChange[
                                                                      i] = true;
                                                                  provider.getTextOnChang(
                                                                      data:
                                                                          textOnChange);
                                                                },
                                                                controller:
                                                                    commentController[
                                                                        i],
                                                                decoration:
                                                                    const InputDecoration(
                                                                        border:
                                                                            InputBorder.none),
                                                                maxLines: 9,
                                                                maxLength: 300,
                                                              ),
                                                            ),
                                                          );
                                                  },
                                        child: Padding(
                                            padding: const EdgeInsets.all(10),
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    commentController[i]
                                                                .text
                                                                .toString()
                                                                .trim()
                                                                .isNotEmpty &&
                                                            prevComments[i] ==
                                                                commentController[
                                                                        i]
                                                                    .text
                                                                    .toString()
                                                                    .trim()
                                                        ? const Icon(
                                                            Icons.check,
                                                            color: Colors.green,
                                                          )
                                                        : const SizedBox(),
                                                    Text(
                                                      "item:${(i + 1)} | ID PDF:${provider.u_id_comments[i]} | owner: ${pdfOwner[i]}",
                                                    ),
                                                    Text(
                                                      commentController[i]
                                                                      .text
                                                                      .length >
                                                                  0 &&
                                                              provider
                                                                  .haveText &&
                                                              prevComments[i] !=
                                                                  commentController[
                                                                          i]
                                                                      .text
                                                                      .toString()
                                                                      .trim()
                                                          ? "..."
                                                          : "",
                                                      style: const TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ).animate().shake()
                                                  ],
                                                ),
                                                Text(provider.original
                                                    ?
                                                    // oak
                                                    pdfGet[i].toString()
                                                    : pdfOriginal[i]
                                                        .toString()),
                                              ],
                                            )),
                                      ),
                                    ),
                                    Positioned(
                                        right: 2,
                                        top: 2,
                                        child: ElevatedButton(
                                            onPressed: () async {
                                              await PdfApi().correctUpdate(
                                                  correct: correct[i] == "1"
                                                      ? "0"
                                                      : "1",
                                                  u_id: provider
                                                      .u_id_comments[i]);
                                              setState(() {});
                                              correct[i] =
                                                  correct[i] == "1" ? "0" : "1";
                                            },
                                            child: Row(
                                              children: [
                                                Text("Correct"),
                                                Checkbox(
                                                  value: correct[i] == "1"
                                                      ? true
                                                      : false,
                                                  onChanged: (value) async {
                                                    await PdfApi().correctUpdate(
                                                        correct:
                                                            correct[i] == "1"
                                                                ? "0"
                                                                : "1",
                                                        u_id: provider
                                                            .u_id_comments[i]);
                                                    setState(() {});
                                                    correct[i] =
                                                        correct[i] == "1"
                                                            ? "0"
                                                            : "1";
                                                  },
                                                )
                                              ],
                                            )))
                                  ],
                                ),
                                SizedBox(
                                    width: double.infinity,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: Text(
                                        provider.l1
                                            ? "L1 use"
                                            : provider.checkGrammar
                                                ? "grammar"
                                                : provider.readOnly
                                                    ? "view comment"
                                                    : "add comment",
                                        style: const TextStyle(
                                            color: Colors.green),
                                        textAlign: TextAlign.end,
                                      ),
                                    )),
                                if (openDetail == i)
                                  ShowDetail(
                                      idCsv: getAllData[i]['id_csv']
                                          .toString()
                                          .substring(
                                              1,
                                              getAllData[i]['id_csv']
                                                      .toString()
                                                      .length -
                                                  1)
                                          .split(","),
                                      allCsv: allCsv,
                                      text: pdfGet[i].toString()),
                                Container(
                                  color: Colors.red.shade200,
                                  width: double.infinity,
                                  height: 2,
                                )
                              ],
                            ),
                          )
                        : const Text('')),
              ))
        ],
      ),
    );
  }
}

class ShowDetail extends StatelessWidget {
  ShowDetail(
      {super.key,
      required this.text,
      required this.allCsv,
      required this.idCsv});
  final String text;
  final List allCsv;
  final List idCsv;
  List data = [];
  getFinde() async {
    // for (String o in idCsv) {
    //   for (dynamic n in allCsv) {
    //     if ("5298" == n['u_id'].toString()) {
    //       data.add(n);
    //       print(n);
    //     }
    //   }
    // }
    // print(data);
    for (String c in idCsv) {
      data.add(allCsv
          .firstWhere((element) => element['u_id'].toString() == c.trim()));
    }
  }

  @override
  Widget build(BuildContext context) {
    getFinde();
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (dynamic d in data)
            SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${d['Expressions']} | errors type: ${d['Error type']}",
                      style: TextStyle(color: Colors.red),
                    ),
                    Text(
                      "sug1 : ${d['Suggestion1']}",
                      style: const TextStyle(color: Colors.amber),
                    ),
                    if (d['Suggestion2'].isNotEmpty)
                      Text(
                        "sug1 : ${d['Suggestion2']}",
                        style: const TextStyle(color: Colors.amber),
                      ),
                    // Container(
                    //   color: Colors.amber,
                    //   height: 2,
                    //   width: double.infinity,
                    // )
                  ],
                ),
              ),
            )
        ],
      ),
    );
  }
}
