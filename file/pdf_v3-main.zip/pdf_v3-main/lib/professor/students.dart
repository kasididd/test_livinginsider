import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:pdf_v3/professor/widget/check_pdf_student.dart';
import 'package:provider/provider.dart';

import '../provider/store.dart';

class Students extends StatefulWidget {
  const Students({super.key});

  @override
  State<Students> createState() => _StudentsState();
}

class _StudentsState extends State<Students> {
  getDataStudents(Store provider) async {
    List res = [];
    provider.userData['master'] == "1"
        ? res = await Users().getMaster()
        : res = await Users().getStudents(provider: provider);
    setState(() {
      visible = List.generate(res.length, (index) => false);

      provider.userData['master'] == "1" ? students = res : students = res;

      check = false;
    });
  }

  bool check = true;

  List students = [], csvFile = [];
  List visible = [];
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (check) {
      getDataStudents(provider);
    }
    return Scaffold(
      body: Center(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: Utility().phone(context)
              ? Utility().size(context).width
              : Utility().size(context).width / 1.5,
          child: Card(
            child: ListView.builder(
              itemCount: students.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                  onTap: () => students[index]['approve'] == "0"
                      ? showApprove(students[index]['user'], provider)
                      : debugPrint("approveed students")
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //       builder: (context) => CheckStudentPDFPro(
                  //           data: students[index]['user'].toString()),
                  //     ))
                  ,
                  child: ListTile(
                    leading: ClipOval(
                      child: Container(
                        color: students[index]['approve'] == "1"
                            ? Colors.green
                            : Colors.red,
                        width: 20,
                        height: 20,
                      ),
                    ),
                    title: Text(
                        jsonDecode(students[index]['data'])['name'].toString()),
                    subtitle: Text(jsonDecode(students[index]['data'])['stuID']
                        .toString()),
                    trailing: Utility().phone(context)
                        ? Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              TextButton(
                                onPressed: () => showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                      title: Column(
                                    children: [
                                      ListTile(
                                        leading: Text("Username"),
                                        trailing: Text("password"),
                                      ),
                                      ListTile(
                                        leading: Text(students[index]['user']),
                                        trailing:
                                            Text(students[index]['password']),
                                      )
                                    ],
                                  )),
                                ),
                                child: Text(
                                  students[index]['user'].toString().length > 6
                                      ? students[index]['user']
                                              .toString()
                                              .substring(0, 6) +
                                          ".."
                                      : students[index]['user'].toString(),
                                ),
                              ),
                              IconButton(
                                  icon: Icon(
                                    Icons.delete,
                                    size: 22,
                                    color: Colors.red,
                                  ),
                                  onPressed: () => showDelete(
                                      provider: provider,
                                      user: students[index]['user'])),
                            ],
                          )
                        : Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                students[index]['user'],
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                visible[index]
                                    ? students[index]['password']
                                    : "********",
                              ),
                              IconButton(
                                icon: Icon(
                                  visible[index]
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  size: 22,
                                ),
                                onPressed: () => setState(() {
                                  visible[index] = !visible[index];
                                }),
                              ),
                              IconButton(
                                  icon: Icon(
                                    Icons.delete,
                                    size: 22,
                                    color: Colors.red,
                                  ),
                                  onPressed: () => showDelete(
                                      provider: provider,
                                      user: students[index]['user'])),
                            ],
                          ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  showApprove(String user, Store provider) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Container(
          height: 150,
          child: Center(
            child: Text("you want to Approve user:$user ?"),
          ),
        ),
        actions: [
          OutlinedButton(
              onPressed: () async {
                await Users().approve(user: user);
                await getDataStudents(provider);
                Navigator.pop(context);
              },
              child: Text("confirm")),
          OutlinedButton(
              onPressed: () => Navigator.pop(context), child: Text("cancel")),
        ],
      ),
    );
  }

  showDelete({required String user, required Store provider}) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Container(
          height: 150,
          child: Center(
            child: Text("you want to delete user:$user ?"),
          ),
        ),
        actions: [
          OutlinedButton(
              onPressed: () async {
                await Users().deleteUser(user: user);
                await getDataStudents(provider);
                Navigator.pop(context);
              },
              child: Text("confirm")),
          OutlinedButton(
              onPressed: () => Navigator.pop(context), child: Text("cancel")),
        ],
      ),
    );
  }
}
