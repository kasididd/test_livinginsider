// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:pdf_v3/professor/check_pdf_select.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

class ListStudents extends StatefulWidget {
  const ListStudents(
      {super.key,
      required this.u_id,
      required this.category,
      required this.roomID});
  final String u_id;
  final String category;
  final String roomID;
  @override
  State<ListStudents> createState() => _ListStudentsState();
}

class _ListStudentsState extends State<ListStudents> {
  List listStudent = [],
      changName = [],
      nameController = <TextEditingController>[];
  List student = [],
      select = [],
      listAdd = [],
      selectStudent = [],
      rawStudent = [];

  getRoomData(Store provider) async {
    student = await Users().getStudents(provider: provider);
    listStudent = await Room().getMember(u_id: widget.u_id);
    select = List.generate(student.length, (index) => "");
    setState(() {
      changName = List.generate(listStudent.length, (index) => false);
      nameController =
          List.generate(listStudent.length, (index) => TextEditingController());
    });

    if (listStudent.isNotEmpty &&
        listStudent[0]['member'].toString().isNotEmpty) {
      await getDataStudent();
      setState(() {
        ready = true;
      });
    }
  }

  bool edit = false, ready = false;
  getDataStudent() async {
    selectStudent = [];
    rawStudent = [];
    List member = listStudent[0]['member'].toString().split(",").toList();
    if (member.isNotEmpty) {
      for (int i = 0; i < member.length; i++) {
        setState(() {
          // เช็คว่ามีข้อมูลที่ตรงกันไหม
          if (student
                  .where((element) => element['u_id'] == member[i])
                  .toString()
                  .length >
              2) {
            selectStudent.add(jsonDecode(student.firstWhere(
                (element) => element['u_id'] == member[i])["data"]));
            rawStudent.add(
                student.firstWhere((element) => element['u_id'] == member[i]));
          }
        });
      }
    }
    for (int i = 0; i < student.length; i++) {
      for (int j = 0; j < member.length; j++) {
        if (member[j] == student[i]['u_id']) {
          select[i] = student[i]['u_id'];
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();

    if (listStudent.isEmpty && widget.category != "MeStudents") {
      getRoomData(provider);
    } else {
      print("kasidid");
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text("Students List"),
        actions: [
          Row(
            children: [
              changName.where((element) => element).toList().isNotEmpty
                  ? IconButton(
                      onPressed: () async {
                        for (int i = 0; i < changName.length; i++) {
                          if (changName[i]) {
                            await Room.Update(
                                u_id: listStudent[i]['u_id'],
                                name: nameController[i].text.trim());
                          }
                        }
                        edit = !edit;
                        await getRoomData(provider);
                        for (int i = 0; i < changName.length; i++) {
                          setState(
                            () => changName[i] = false,
                          );
                        }
                      },
                      icon: const Icon(Icons.save))
                  : IconButton(
                      onPressed: () async => {
                            addRoom(context, provider),
                          },
                      icon: const Icon(Icons.edit)),
            ],
          )
        ],
      ),
      body: listStudent.isEmpty
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 4),
              child: selectStudent.isEmpty
                  ? const Center(
                      child: Text("No students..."),
                    )
                  : ListView.builder(
                      itemCount: selectStudent.length,
                      itemBuilder: (context, index) => Card(
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => CheckPdfSelect(
                                                roomID: widget.roomID,
                                                name: jsonDecode(
                                                    rawStudent[index]
                                                        ['data'])['name'],
                                                user: rawStudent[index]['user'],
                                                category: widget.category,
                                              )
                                          // StudentsPDF(
                                          //       user: rawStudent[index]['user'],
                                          //       category: widget.category,
                                          //     )
                                          ));
                                },
                                child: ListTile(
                                  leading: Text(selectStudent[index]['name']),
                                  trailing: Text(selectStudent[index]['stuID']),
                                )),
                          )),
            ),
    );
  }

  addRoom(context, Store provider) async {
    await showDialog(
        context: context,
        builder: (context) {
          final GlobalKey<FormState> formKey = GlobalKey<FormState>();
          void validateAndSave() async {
            {
              for (int i = 0; i < select.length; i++) {
                if (select[i].isNotEmpty) {
                  listAdd.add(select[i]);
                  if (select[i].isNotEmpty) {
                    await Room.AddStudent(
                        u_id: widget.u_id, name: listAdd.join(","));
                  }
                }
              }
              if (select.join().isEmpty) {
                await Room.AddStudent(u_id: widget.u_id, name: "");
              }

              // อับเดทข้้อมูลนักศึกษาที่เลือก
              selectStudent = [];
              List member =
                  listStudent[0]['member'].toString().split(",").toList();
              selectStudent = [];
              member = listAdd;
              for (int i = 0; i < member.length; i++) {
                setState(() {
                  selectStudent.add(jsonDecode(student.firstWhere(
                      (element) => element['u_id'] == member[i])["data"]));
                });
              }
              for (int i = 0; i < student.length; i++) {
                for (int j = 0; j < member.length; j++) {
                  if (member[j] == student[i]['u_id']) {
                    select[i] = student[i]['u_id'];
                  }
                }
              }
              if (listAdd.isEmpty) {
                setState(() {
                  selectStudent = [];
                });
              }
// ล้างข้อมูลที่Insert
              listAdd = [];

              Navigator.pop(context);
            }
          }

          return AlertDialog(
            title: const Text("add students"),
            content: StatefulBuilder(
              builder: (context, setState) => SizedBox(
                width: 400,
                height: Utility().size(context).height / 1.3,
                child: Form(
                  key: formKey,
                  child: Column(
                    children: [
                      Expanded(
                          child: ListView.builder(
                        itemCount: student.length,
                        itemBuilder: (context, index) => GestureDetector(
                          onTap: () => setState(() {
                            if (select[index].toString().isEmpty) {
                              select[index] = student[index]['u_id'];
                            } else {
                              select[index] = "";
                            }
                          }),
                          child: Card(
                            elevation: "" == select[index] ? 0 : 8,
                            child: ListTile(
                              leading: Text(
                                  jsonDecode(student[index]['data'])['name']),
                              trailing: Text(
                                  jsonDecode(student[index]['data'])['stuID']),
                            ),
                          ),
                        ),
                      )),
                      OutlinedButton(
                          onPressed: () async {
                            validateAndSave();
                          },
                          child: const Text("อัปเดทข้อมูล"))
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}
