import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

class CsvPage extends StatefulWidget {
  const CsvPage({super.key, required this.data});
  final dynamic data;
  @override
  State<CsvPage> createState() => _CsvPageState();
}

class _CsvPageState extends State<CsvPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {});
    // TODO: implement initState
    super.initState();
  }

  getData() async {
    var res = await CsvManage.getApi(name: widget.data);
    setState(() {
      data = jsonDecode(res);
      print(data.length);
    });
  }

  List data = [];
  List val = [];
  bool edit = false;
  // List val = List.generate(234, (index) => false);
  setLen(len) {
    val = List.generate(len, (index) => false);
  }

  getProvider(get) {
    setState(() {
      data = get;
      if (val.isEmpty) {
        setLen(data.length);
      }
    });
  }

  bool check = true;

  @override
  Widget build(BuildContext context) {
    if (!edit) setLen(data.length);
    Size size = MediaQuery.of(context).size;
    Store provider = context.watch<Store>();
    getProvider(
        provider.Allcsv.where((e) => e['name_csv'] == widget.data).toList());
    if (check) {
      // getData();
      check = !check;
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.data),
        actions: [
          Row(
            children: [
              !edit
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18.0),
                      child: IconButton(
                          onPressed: () async {
                            await showDialog(
                                context: context,
                                builder: (context) {
                                  final GlobalKey<FormState> formKey =
                                      GlobalKey<FormState>();
                                  TextEditingController Expressions =
                                      TextEditingController();
                                  TextEditingController Suggestion1 =
                                      TextEditingController();
                                  TextEditingController Suggestion2 =
                                      TextEditingController();
                                  TextEditingController eRtype =
                                      TextEditingController();
                                  void validateAndSave() async {
                                    final FormState? form =
                                        formKey.currentState;
                                    if (form!.validate()) {
                                      {
                                        await CsvManage().InsertOne(
                                            eRtype: eRtype.text.trim(),
                                            owner: provider.userData['u_id']
                                                .toString(),
                                            name: widget.data,
                                            Expressions:
                                                Expressions.text.trim(),
                                            Suggestion1:
                                                Suggestion1.text.trim(),
                                            Suggestion2:
                                                Suggestion2.text.trim());

                                        await getData();
                                        await setLen(data.length);
                                        Navigator.pop(context);
                                      }
                                    } else {
                                      print('Form is invalid');
                                    }
                                  }

                                  return AlertDialog(
                                    title: const Text("เพิ่ม csv"),
                                    content: SizedBox(
                                      width: 300,
                                      height: 400,
                                      child: Form(
                                        key: formKey,
                                        child: Column(
                                          children: [
                                            Expanded(
                                                child: TextFormField(
                                              validator: (value) =>
                                                  value!.isEmpty
                                                      ? "โปรดกรอกข้อมูล"
                                                      : null,
                                              decoration: const InputDecoration(
                                                  label: Text("Expressions")),
                                              controller: Expressions,
                                            )),
                                            Expanded(
                                                child: TextFormField(
                                              validator: (value) =>
                                                  value!.isEmpty
                                                      ? "โปรดกรอกข้อมูล"
                                                      : null,
                                              decoration: const InputDecoration(
                                                  label: Text("Suggestion1")),
                                              controller: Suggestion1,
                                            )),
                                            Expanded(
                                              child: TextFormField(
                                                validator: (value) =>
                                                    value!.isEmpty
                                                        ? null
                                                        : null,
                                                decoration:
                                                    const InputDecoration(
                                                        label: Text(
                                                            "Suggestion2")),
                                                controller: Suggestion2,
                                              ),
                                            ),
                                            Expanded(
                                              child: TextFormField(
                                                validator: (value) =>
                                                    value!.isEmpty
                                                        ? null
                                                        : null,
                                                decoration:
                                                    const InputDecoration(
                                                        label:
                                                            Text("Error type")),
                                                controller: eRtype,
                                              ),
                                            ),
                                            OutlinedButton(
                                                onPressed: () async {
                                                  validateAndSave();
                                                },
                                                child: const Text("เพิ่ม CSV"))
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                });
                          },
                          icon: const Icon(
                            Icons.add,
                          )),
                    )
                  : Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18.0),
                      child: IconButton(
                          onPressed: () {
                            setState(() async {
                              List uId = [];
                              for (int i = 0; i < val.length; i++) {
                                if (val[i]) {
                                  uId.add(data[i]['u_id']);
                                }
                              }

                              await CsvManage.deleteById(
                                  name: widget.data, u_id: uId);
                              getData();
                              edit = !edit;
                            });
                          },
                          icon: const Icon(
                            Icons.delete,
                            color: Colors.red,
                          )),
                    ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18.0),
                child: IconButton(
                    onPressed: () {
                      setState(() {
                        edit = !edit;
                      });
                    },
                    icon: edit
                        ? const Icon(Icons.close)
                        : const Icon(Icons.edit)),
              ),
            ],
          )
        ],
      ),
      body: Padding(
          padding: const EdgeInsets.all(10),
          child: data.isEmpty
              ? const Text('ว่าง')
              : Column(
                  children: [
                    if (size.width > size.height)
                      Row(
                        children: const [
                          Text(
                            "ลำดับที่ ${0 + 1}  ",
                            style: TextStyle(color: Colors.transparent),
                          ),
                          Expanded(flex: 1, child: Text('Expressions')),
                          Expanded(
                              flex: 1,
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 8.0),
                                child: Text('Suggestion1'),
                              )),
                          Expanded(flex: 1, child: Text('Suggestion2')),
                        ],
                      ),
                    Expanded(
                      child: ListView.builder(
                        addAutomaticKeepAlives: true,
                        addRepaintBoundaries: false,
                        itemCount: data.length,
                        itemBuilder: (context, i) => size.width > size.height
                            ? Row(
                                children: [
                                  if (edit)
                                    Checkbox(
                                      value: val[i],
                                      onChanged: (value) {
                                        setState(() {
                                          val[i] = value;
                                        });
                                      },
                                    ),
                                  Text("ลำดับที่ ${i + 1}  "),
                                  Expanded(
                                      flex: 1,
                                      child: SelectableText(
                                          data[i]['Expressions'])),
                                  Expanded(
                                      flex: 1,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8.0),
                                        child: SelectableText(
                                            data[i]['Suggestion1']),
                                      )),
                                  Expanded(
                                      flex: 1,
                                      child: SelectableText(
                                          data[i]['Suggestion2'])),
                                ],
                              )
                            : i == 0
                                ? const Text('')
                                : Card(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          if (edit)
                                            Checkbox(
                                              value: val[i],
                                              onChanged: (value) {
                                                setState(() {
                                                  val[i] = value;
                                                });
                                              },
                                            ),
                                          Text("ลำดับที่ $i"),
                                          SelectableText(
                                              "Ex : ${data[i]['Expressions']}"),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 8.0),
                                            child: SelectableText(
                                                "St1 : ${data[i]['Suggestion1']}"),
                                          ),
                                          SelectableText(
                                              "St2 : ${data[i]['Suggestion2']}"),
                                        ],
                                      ),
                                    ),
                                  ),
                        // children: [

                        //   for (int i = 0; i < data.length; i++)

                        // ],
                      ),
                    ),
                  ],
                )),
    );
  }
}
