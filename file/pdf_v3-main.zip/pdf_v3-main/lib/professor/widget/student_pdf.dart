import 'dart:collection';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';

import '../../API/check_grammar.dart';

class StudentsPDF extends StatefulWidget {
  const StudentsPDF({super.key, required this.user, required this.category});
  final String user;
  final String category;
  @override
  State<StudentsPDF> createState() => StudentsPDFState();
}

class StudentsPDFState extends State<StudentsPDF> {
  List<OrderModel> order = <OrderModel>[];

  int sumPoint = 0;
  int fullPoint = 60;
  TextEditingController val = TextEditingController();
  List csvFile = [];
  List pdfGet = [], listPoint = [];
  bool itEmpty = false;
  getPdf(Store provider) async {
    List categoryCsv =
        jsonDecode(await CsvApi.getApi(owner: provider.userData['u_id']));
    List d =
        categoryCsv.map((e) => (e['name'].toString().split('.')[0])).toList();
    order = <OrderModel>[];
    d.map((e) => order.add(OrderModel(name: e, items: []))).toList();
    var respond = await PdfApi()
        .getPdfStudent(user: widget.user, category: widget.category);

    if (respond == "empty") {
      setState(() {
        itEmpty = true;
      });
    } else {
      setState(() {
        List test = jsonDecode(respond);
        List newList = [];
        sumPoint = 0;
        for (int i = 0; i < test.length; i++) {
          if (test[i]['text'][0] == "[") {
            String text = test[i]['text'].toString();
            List d = (text.substring(1, text.length - 1).split(","));
            List<int> eUtf8 = [];
            for (String a in d) {
              eUtf8.add(int.parse(a));
            }
            newList.add(test[i]);
            newList[i]['text'] = (utf8.decode(eUtf8).split(".").join(".\n"));
            // listPoint.add(0);
          } else {
            newList.add(test[i]);
            // listPoint.add(0);
          }
        }
        listPoint = [];
        // save zone
        pdfGet = newList.reversed.toList();
        for (int i = 0; i < pdfGet.length; i++) {
          checkPoint(pdfGet[i]['text']);
          order
              .map((e) => e.name == pdfGet[i]['category']
                  ? e.items.add(pdfGet[i]['u_id'])
                  : e.name)
              .toList();
        }
      });
    }
    print(order.asMap().entries.map((e) => e.value.items.isNotEmpty
        ? {
            e.value.items.reversed,
            print(e.key),
            draftList.add(DraftListModel(
                name: e.value.name, u_id: e.value.items.reversed.toList()))
          }
        : e.value.name));
    loading = false;
  }

  List<DraftListModel> draftList = [];
  bool loading = true;
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (loading) {
      getPdf(provider);
    }
    if (draftList.isEmpty) {}
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.user),
      ),
      body: pdfGet.isEmpty
          ? Center(
              child: itEmpty
                  ? const Text("ไม่มีข้อมูลการส่งงาน")
                  : const CircularProgressIndicator(),
            )
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 4),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    flex: 6,
                    child: Column(
                      children: [
                        Expanded(
                          child: ListView.builder(
                            itemCount: draftList.length,
                            itemBuilder: (context, i) => Column(
                              children: [
                                Text(draftList[i].name),
                                for (int index = 0;
                                    index < draftList[i].u_id.length;
                                    index++)
                                  pdfGet[0] == 0
                                      ? const Text("ไม่มีข้อมูล")
                                      : mainShowData(context, i, index),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: Center(
                        child: Card(
                          clipBehavior: Clip.antiAlias,
                          child: ListTile(
                            title: const Text(
                              "Point",
                              style: TextStyle(fontSize: 30),
                            ),
                            trailing: pdfGet[0] == 0
                                ? const Text("ไม่มีข้อมูล")
                                : Text(
                                    sumPoint.toString(),
                                    style: TextStyle(
                                        fontSize: 30,
                                        color: (sumPoint > (fullPoint * 0.8))
                                            ? Colors.green
                                            : Colors.red),
                                  ),
                          ),
                        ),
                      ))
                ],
              ),
            ),
    );
  }

  Material mainShowData(BuildContext context, int i, int index) {
    return Material(
      child: Stack(
        children: [
          Card(
              clipBehavior: Clip.antiAlias,
              elevation: 2,
              child: InkWell(
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ShowPdf(
                          title: pdfGet.firstWhere((element) =>
                              element['u_id'] == draftList[i].u_id[index])),
                    )),
                child: ListTile(
                  leading: Text(
                      'Submit ${pdfGet.firstWhere((element) => element['u_id'] == draftList[i].u_id[index])['time']}'),
                  trailing: Text(
                    pdfGet.firstWhere((element) =>
                                element['u_id'] ==
                                draftList[i].u_id[index])['correct'] ==
                            "1"
                        ? "Correct"
                        : pdfGet.firstWhere((element) =>
                                    element['u_id'] ==
                                    draftList[i].u_id[index])['RawSuggest'] ==
                                "0"
                            ? "Not check"
                            : listPoint[index] == 0
                                // ถูกทั้งหมด
                                ? "wait for check"
                                : "Wrong ${listPoint[index]}",
                    style: TextStyle(
                        color: pdfGet.firstWhere((element) =>
                                    element['u_id'] ==
                                    draftList[i].u_id[index])['RawSuggest'] ==
                                "0"
                            ? Colors.amber
                            : listPoint[index] == 0 ||
                                    pdfGet.firstWhere((element) =>
                                            element['u_id'] ==
                                            draftList[i]
                                                .u_id[index])['correct'] ==
                                        "1"
                                ? Colors.green
                                : Colors.red),
                  ),
                ),
              )),
          if (pdfGet
              .firstWhere((element) =>
                  element['u_id'] == draftList[i].u_id[index])['comment']
              .toString()
              .isNotEmpty)
            const Positioned(
                right: 0,
                top: 0,
                child: Icon(
                  Icons.message,
                  color: Colors.amber,
                  size: 20,
                )),
          Positioned(
              left: 0,
              top: 0,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                    color: Colors.purple,
                    borderRadius: BorderRadius.circular(10)),
                child: Text(
                  "Draft ${index + 1}",
                  style: TextStyle(fontSize: 12, color: Colors.white),
                ),
              )),
        ],
      ),
    );
  }

  checkPoint(String data) {
    int pointThis = 0;
    for (int i = 0; i < data.length; i++) {
      if (data[i] == "[") {
        pointThis += 1;
      }
    }
    listPoint.add(pointThis);
    sumPoint += pointThis;
  }
}

class ShowPdf extends StatefulWidget {
  const ShowPdf({super.key, required this.title});
  final dynamic title;
  @override
  State<ShowPdf> createState() => _ShowPdfState();
}

class _ShowPdfState extends State<ShowPdf> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text(widget.title['time']),
        actions: [
          IconButton(
              onPressed: () {
                _createPdf();
              },
              icon: const Icon(Icons.print))
        ],
      ),
      body: SizedBox(
        width: double.infinity,
        child: Center(
          child: SizedBox(
            width: Utility().phone(context)
                ? double.infinity
                : Utility().size(context).width / 2,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Card(
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () {
                        checkGrammar();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(widget.title['text']),
                      ),
                    ),
                  ),
                  if (widget.title['comment'].toString().isNotEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(widget.title['comment']),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void checkGrammar() {
    String checkTextDecode = widget.title['text'];
    int start = 0, end = 0, j = 0;
    List deBrucked = [], result = [];
    for (j; j < checkTextDecode.length; j++) {
      if (checkTextDecode[j] == "[") {
        start = j;
      }
      if (checkTextDecode[j] == "]") {
        end = j;
        for (int o = start; o <= end; o++) {
          deBrucked.add(o);
        }
      }
    }
    for (int p = 0; p < checkTextDecode.length; p++) {
      if (deBrucked.where((element) => element == p).toList().isEmpty) {
        result.add(checkTextDecode[p]);
      }
    }
    print(checkTextDecode);
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CheckGrammar(data: result.join().trim()),
        ));
  }

  void _createPdf() async {
    final doc = pw.Document();

    final ttf = await fontFromAssetBundle('assets/THSarabunNew.ttf');

    // for (int i = 0; i < 4; i++)
    {
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  // for (int i = 0; i < 10; i++)
                  pw.Text(widget.title['text'],
                      style: pw.TextStyle(font: ttf, fontSize: 18)),
                  if (widget.title['comment'].toString().trim().isNotEmpty)
                    pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Container(
                              color: PdfColors.black,
                              width: double.infinity,
                              height: 1),
                          pw.Center(
                              child: pw.Text("comment",
                                  style:
                                      pw.TextStyle(font: ttf, fontSize: 18))),
                          pw.SizedBox(
                            width: double.infinity,
                            child: pw.Text(widget.title['comment'],
                                style: pw.TextStyle(font: ttf, fontSize: 18)),
                          )
                        ])
                ]); // Center
          },
        ),
      );
    }
    await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => doc.save());
  }
}

class OrderModel {
  OrderModel({required this.name, required this.items});
  String name;
  List items;
}

class DraftListModel {
  DraftListModel({required this.name, required this.u_id});
  String name;
  List u_id;
}
