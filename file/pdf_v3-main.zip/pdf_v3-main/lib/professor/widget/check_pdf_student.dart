import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../API/crude.dart';
import '../../API/func.dart';
import '../../provider/store.dart';

class CheckStudentPDFPro extends StatefulWidget {
  const CheckStudentPDFPro({super.key, required this.data});
  final String data;
  @override
  State<CheckStudentPDFPro> createState() => _StudentPDFState();
}

class _StudentPDFState extends State<CheckStudentPDFPro> {
  // ข้อความในการแจ้งเตือนต่างๆ
  String msg = "";
  String? pdf;
  List? pdfGet;
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {});
    super.initState();
  }

  getNumberExpress(int k) {
    int numberExpress = 0;

    numberExpress = res
        .where((element) => element['Expressions'] == res[k]['Expressions'])
        .toList()
        .length;
    return numberExpress;
  }

  checkNumberExpress(int k) {
    return res.indexWhere(
        (element) => element['Expressions'] == res[k]['Expressions']);
  }

  List click = [];
  bool check = true;
  List data = [];
  List res = [];
  checkData(provider, numer) async {
    res = [];
    int k = 0;
    for (String da in data) {
      for (int i = 0; i < provider.Allcsv.length; i++) {
        if (provider.Allcsv[i]['Expressions'].toString().toLowerCase() ==
            da.toLowerCase()) {
          res.add(await provider.Allcsv[i]);
          numer[k] = true;
        }
      }
      k++;
    }
  }

  int i = 0;
  int index = -1;
  List numer = [];
  int font = 0;
  List select = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool windows = size.width > size.height;
    font = 0;
    Store provider = context.watch<Store>();
    if (check) {
      getPdf(widget.data);
      check = !check;
    }

    return Scaffold(
      appBar: AppBar(),
      body: check
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SizedBox(
              width: size.width,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      width: windows ? size.width / 1.4 : size.width,
                      child: Column(
                        children: [
                          SizedBox(
                            child: Column(
                              children: const [],
                            ),
                          ),
                          Expanded(
                              flex: 7,
                              child: SizedBox(
                                width: size.width,
                                child: Card(
                                  clipBehavior: Clip.antiAlias,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)),
                                  elevation: 8,
                                  child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8),
                                      decoration: const BoxDecoration(
                                          shape: BoxShape.circle),
                                      child: pdfGet != null
                                          ? ListView(
                                              children: [
                                                for (int i = 0;
                                                    i < pdfGet!.length;
                                                    i++)
                                                  Card(
                                                    clipBehavior:
                                                        Clip.antiAlias,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5)),
                                                    child: InkWell(
                                                      onTap: click[i]
                                                          ? null
                                                          : () async {
                                                              setState(() {
                                                                l = 0;
                                                                font = 0;
                                                                data = Func().convertSplit(
                                                                    professor:
                                                                        pdfGet![i]
                                                                            [
                                                                            'IDprofessor'],
                                                                    category:
                                                                        pdfGet![i]
                                                                            [
                                                                            'category'],
                                                                    provider:
                                                                        provider,
                                                                    get: pdfGet![
                                                                            i][
                                                                        'text']);
                                                                click[i] = true;
                                                                for (int j = 0;
                                                                    j <
                                                                        pdfGet!
                                                                            .length;
                                                                    j++) {
                                                                  if (j != i) {
                                                                    click[j] =
                                                                        false;
                                                                  }
                                                                }
                                                                textResult = List
                                                                    .generate(
                                                                        data
                                                                            .length,
                                                                        (index) =>
                                                                            "");
                                                              });
                                                              numer =
                                                                  List.generate(
                                                                      data
                                                                          .length,
                                                                      (index) =>
                                                                          false);
                                                              select =
                                                                  List.generate(
                                                                      data
                                                                          .length,
                                                                      (index) =>
                                                                          0);
                                                              await checkData(
                                                                  provider,
                                                                  numer);
                                                              index = i;
                                                            },
                                                      child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(10),
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  Text(
                                                                      "Pages ${(i + 1).toString()}"),
                                                                  !click[i]
                                                                      ? ClipOval(
                                                                          child:
                                                                              Container(
                                                                            color:
                                                                                Colors.red,
                                                                            width:
                                                                                20,
                                                                            height:
                                                                                20,
                                                                          ),
                                                                        )
                                                                      : IconButton(
                                                                          onPressed: () => print(textResult
                                                                              .join(";")
                                                                              .toString()
                                                                              .replaceAll(";", "\n")
                                                                              .trim()),
                                                                          icon: const Icon(Icons.save))
                                                                ],
                                                              ),
                                                              click[i] &&
                                                                      i == index
                                                                  ? Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        for (int j =
                                                                                0;
                                                                            j < data.length;
                                                                            j++)
                                                                          numer[j]
                                                                              ? openMenu(
                                                                                  page: i,
                                                                                  index: j,
                                                                                  context: context,
                                                                                  sug1: findValue(j)['Suggestion1'],
                                                                                  sug2: findValue(j)['Suggestion2'],
                                                                                  text: select[j] == 1
                                                                                      ? findValue(j)['Suggestion1']
                                                                                      : select[j] == 2
                                                                                          ? findValue(j)['Suggestion2']
                                                                                          : "[${font += 1}] ${data[j].toString()}")
                                                                              : Text(data[j].toString()),
                                                                        //  OpenMenu(),
                                                                      ],
                                                                    )
                                                                  // ไฟล์ดิบ
                                                                  : Text(pdfGet![
                                                                              i]
                                                                          [
                                                                          'text']
                                                                      .toString()),
                                                            ],
                                                          )),
                                                    ),
                                                  )
                                              ],
                                            )
                                          : const Text('')),
                                ),
                              ))
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Future pickPdf() async {
    try {
      final pic = await FilePicker.platform
          .pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
      var res = pic!.files.first.bytes;
      Uint8List? base64 = res;
      pdf = base64Encode(base64!);
      setState(() {
        msg = pic.names.toString();
      });
    } catch (e) {
      print(e);
    }
  }

  getPdf(data) async {
    var respond = await PdfApi.getApiSelectWidget(user: data);
    setState(() {
      List newList = jsonDecode(respond);

      pdfGet = newList.reversed.toList();
      click = List.generate(pdfGet!.length, (index) => false);
    });
  }

  int l = 0;
  List textResult = [];
  openMenu(
      {required page,
      required sug1,
      required text,
      required sug2,
      required context,
      required index}) {
    setState(() {
      l++;
      for (int i = 0; i < numer.length; i++) {
        if (numer[index]) {
          textResult[index] = text;
        }
        if (!numer[i]) {
          textResult[i] = data[i];
        }
      }
    });
    return InkWell(
      onTap: () {
        final action = CupertinoActionSheet(
          title: const Text(
            "เลือก Suggestion",
            style: TextStyle(fontSize: 30),
          ),
          actions: <Widget>[
            CupertinoActionSheetAction(
              onPressed: () {
                setState(() {
                  l = 0;
                  select[index] = 1;
                });
                Navigator.pop(
                  context,
                );
              },
              child: Text(sug1),
            ),
            if (sug2.isNotEmpty)
              CupertinoActionSheetAction(
                onPressed: () {
                  setState(() {
                    select[index] = 2;
                  });
                  Navigator.pop(context);
                },
                child: Text(sug2),
              ),
          ],
          cancelButton: CupertinoActionSheetAction(
            isDestructiveAction: true,
            onPressed: () {
              setState(() {
                select[index] = 0;
              });
              Navigator.pop(context);
            },
            child: const Text("Cancel"),
          ),
        );

        showCupertinoModalPopup(context: context, builder: (context) => action);
      },
      child: Text(
        text,
        style:
            TextStyle(color: select[index] != 0 ? Colors.green : Colors.amber),
      ),
    );
  }

  findValue(j) {
    var result = res.firstWhere((element) => element['Expressions'] == data[j]);
    return result;
  }
}
