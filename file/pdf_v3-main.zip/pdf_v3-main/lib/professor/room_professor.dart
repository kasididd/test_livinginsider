import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../API/crude.dart';
import '../API/func.dart';
import '../professor/widget/room.dart';
import '../provider/store.dart';

class RoomProfessor extends StatefulWidget {
  const RoomProfessor(
      {super.key, required this.csv_id, required this.category});
  final String csv_id;
  final String category;
  @override
  State<RoomProfessor> createState() => _RoomProfessorState();
}

class _RoomProfessorState extends State<RoomProfessor> {
  @override
  void dispose() {
    nameController.map((e) => e..dispose()).toList();
    super.dispose();
  }

  List roomData = [],
      changName = [],
      allRoomData = [],
      nameController = <TextEditingController>[];

  fetchRoom({required Store provider}) async {
    List p = await Users().getProfessor();
    p = (p.map((e) => e['user']).toList());
    p.asMap().entries.map((e) async {
      var r = await Room().getAllRommForStudents(
          user: e.value, u_id: provider.userData['u_id']);
      if (r == "empty") {
      } else {
        allRoomData.add({"name": e.value, "data": r});
      }

      if (e.key == p.length - 1) {
        waiting = false;
        setState(() {});
      }
    }).toList();
  }

  bool waiting = true;
  getRoomData(Store provider) async {
    allRoomData = [];
    await fetchRoom(provider: provider);
    allRoomData.isEmpty ? itEmpty = true : roomData = allRoomData[0]['data'];
    setState(() {
      changName = List.generate(roomData.length, (index) => false);
      nameController =
          List.generate(roomData.length, (index) => TextEditingController());
    });
  }

  bool edit = false, itEmpty = false;
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();

    if (roomData.isEmpty && !itEmpty) {
      getRoomData(provider);
    }
    return Scaffold(
      body: waiting
          ? Center(
              child: !itEmpty
                  ? const CircularProgressIndicator()
                  : const Text("no data"),
            )
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 4),
              child: SingleChildScrollView(
                child: SizedBox(
                  height: Utility().size(context).height * .9,
                  child: allRoomData.isEmpty
                      ? Center(
                          child: Text("No data..."),
                        )
                      : Column(
                          children: [
                            for (int number = 0;
                                number < allRoomData.length;
                                number++)
                              Expanded(
                                child: Column(
                                  children: [
                                    Text(allRoomData[number]['name']),
                                    Expanded(
                                      child: ListView.builder(
                                        itemCount:
                                            allRoomData[number]['data'].length,
                                        itemBuilder: (context, index) =>
                                            Material(
                                          child: Card(
                                              clipBehavior: Clip.antiAlias,
                                              elevation: 2,
                                              child: InkWell(
                                                onTap: edit
                                                    ? null
                                                    : () => Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) => ListStudents(
                                                              roomID: allRoomData[
                                                                          number]
                                                                      ['data'][index]
                                                                  ['u_id'],
                                                              u_id: allRoomData[
                                                                          number]
                                                                      ['data'][index]
                                                                  ['u_id'],
                                                              category: widget
                                                                  .category),
                                                        )),
                                                child: ListTile(
                                                  leading: Text(
                                                    allRoomData[number]['data']
                                                        [index]['room_name'],
                                                    style: const TextStyle(
                                                        fontSize: 17),
                                                  ),
                                                ),
                                              )),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                ),
              ),
            ),
    );
  }
}
