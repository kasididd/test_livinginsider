// ignore_for_file: non_constant_identifier_names

import 'dart:async';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:provider/provider.dart';

import '../provider/store.dart';

class CheckStudentPDF extends StatefulWidget {
  const CheckStudentPDF({super.key});

  @override
  State<CheckStudentPDF> createState() => _StudentPDFState();
}

class _StudentPDFState extends State<CheckStudentPDF> {
  // ข้อความในการแจ้งเตือนต่างๆ
  List<int> file = [];
  String msg = "", roomID = "";
  String? pdf;
  bool loaded = false;
  List? pdfGet;
  String IDprofessor = "";
  getNumberExpress(int k) {
    int numberExpress = 0;

    numberExpress = res
        .where((element) => element['Expressions'] == res[k]['Expressions'])
        .toList()
        .length;
    return numberExpress;
  }

  checkNumberExpress(int k) {
    return res.indexWhere(
        (element) => element['Expressions'] == res[k]['Expressions']);
  }

  List click = [];
  bool check = true;
  List data = [];
  List res = [], isSave = [];
  // หัวข้อ
  String? category, professor, room;
  List categories = [], listProfessor = [], roomSelect = <RoomDropdownModel>[];
  checkData(Store provider, numer) async {
    res = [];
    int k = 0;
    for (String da in data) {
      for (int i = 0; i < provider.Allcsv.length; i++) {
        if (provider.Allcsv[i]['Expressions'].toString().toLowerCase() ==
            da.toLowerCase()) {
          res.add(await provider.Allcsv[i]);
          numer[k] = true;
        }
      }
      k++;
    }
  }

  int i = 0;
  int index = -1;
  List numer = [];
  int font = 0;
  List select = [];
  List prevData = [];
  TextEditingController typeText = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool windows = size.width > size.height;
    font = 0;
    Store provider = context.watch<Store>();
    if (check) getPdf(provider);

    return check && loaded
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : SizedBox(
            width: size.width,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: windows ? size.width / 1.4 : size.width,
                    child: Column(
                      children: [
                        SizedBox(
                          child: Column(
                            children: [
                              DropdownButton(
                                items: listProfessor
                                    .map((e) => jsonDecode(e['data'])['name'])
                                    .toList()
                                    .map((e) => DropdownMenuItem(
                                        value: e, child: Text(e)))
                                    .toList(),
                                value: professor,
                                hint: const Text("Professor"),
                                onChanged: (value) async {
                                  dropDownProfessor(value, provider);
                                  String owner = await listProfessor.firstWhere(
                                      (element) =>
                                          jsonDecode(element['data'])['name']
                                              .toString()
                                              .trim() ==
                                          professor.toString().trim())['u_id'];
                                  List csv_cate = jsonDecode(
                                      await CsvApi.getApi(owner: owner));
                                  provider.getCsvCate(
                                      data: csv_cate
                                          .map((e) => CsvCateModel(
                                              u_id: e['u_id'],
                                              name: e['name'],
                                              time: e['time']))
                                          .toList());
                                  categories = (provider.csvCate
                                      .map((e) => e.name
                                          .substring(0, e.name.length - 4))
                                      .toList());
                                },
                              ),
                              DropdownButton(
                                items: categories
                                    .map((e) => DropdownMenuItem(
                                        value: e, child: Text(e)))
                                    .toList(),
                                value: category,
                                hint: const Text("Category"),
                                onChanged: (value) => setState(() {
                                  category = value.toString();
                                }),
                              ),
                              DropdownButton(
                                items: roomSelect
                                    .map((e) => e)
                                    .toList()
                                    .map((e) => DropdownMenuItem(
                                        value: e.name, child: Text(e.name)))
                                    .toList(),
                                value: room,
                                hint: const Text("Select room"),
                                onChanged: (value) => setState(() {
                                  room = value.toString();
                                  roomID = roomSelect
                                      .firstWhere(
                                          (element) => element.name == value)
                                      .room_id;
                                }),
                              ),
                              if (category != null &&
                                  professor != null &&
                                  room != null)
                                Container(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  width: size.width,
                                  child: Column(
                                    children: [
                                      TextButton(
                                          onPressed: () async => {
                                                showDialog(
                                                  context: context,
                                                  builder: (context) =>
                                                      AlertDialog(
                                                    title: Text("Type data"),
                                                    content: TextField(
                                                        onChanged: (value) =>
                                                            setState(() {}),
                                                        controller: typeText,
                                                        maxLines: 18),
                                                  ),
                                                )
                                              },
                                          child: const Text(
                                            "Text field",
                                            style: TextStyle(fontSize: 24),
                                          )),
                                      TextButton(
                                          onPressed: () async =>
                                              {await pickPdf()},
                                          child: const Text(
                                            "Pick PDF",
                                            style: TextStyle(fontSize: 24),
                                          )),
                                    ],
                                  ),
                                ),
                              Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                width: size.width,
                                child: TextButton(
                                    onPressed: pdf == null &&
                                            typeText.text.toString().isEmpty
                                        ? null
                                        : () async {
                                            setState(() {
                                              loaded = true;
                                            });
                                            typeText.text.toString().isEmpty
                                                ? await PdfApi.uploadPdf(
                                                    IDprofessor: IDprofessor,
                                                    category: category!,
                                                    pdf: file,
                                                    provider: provider,
                                                    room_id: roomID)
                                                : {
                                                    await PdfApi().insertText(
                                                        IDprofessor:
                                                            IDprofessor,
                                                        cate: category!,
                                                        text: typeText.text
                                                            .trim(),
                                                        user: provider
                                                            .userData['user'],
                                                        room_id: roomID)
                                                  };

                                            await getPdf(provider);
                                          },
                                    child: Text(
                                      "Upload data $msg",
                                      style: const TextStyle(fontSize: 18),
                                    )),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                            flex: 7,
                            child: SizedBox(
                              width: size.width,
                              child: Card(
                                clipBehavior: Clip.antiAlias,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15)),
                                elevation: 8,
                                child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle),
                                    child: pdfGet != null && loaded
                                        ? ListView(
                                            children: [
                                              for (int i = 0;
                                                  i < pdfGet!.length;
                                                  i++)
                                                Card(
                                                  clipBehavior: Clip.antiAlias,
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5)),
                                                  child: InkWell(
                                                    onTap: isSave[i] ||
                                                            index == i
                                                        ? null
                                                        : () async {
                                                            setState(() {
                                                              l = 0;
                                                              font = 0;
                                                              data = Func().convertSplit(
                                                                  professor:
                                                                      pdfGet![i]
                                                                          [
                                                                          'IDprofessor'],
                                                                  category: pdfGet![
                                                                          i][
                                                                      'category'],
                                                                  provider:
                                                                      provider,
                                                                  get: pdfGet![
                                                                          i]
                                                                      ['text']);

                                                              click[i] = true;
                                                              for (int j = 0;
                                                                  j <
                                                                      pdfGet!
                                                                          .length;
                                                                  j++) {
                                                                if (j != i) {
                                                                  click[j] =
                                                                      false;
                                                                }
                                                              }
                                                              textResult =
                                                                  List.generate(
                                                                      data
                                                                          .length,
                                                                      (index) =>
                                                                          "");
                                                            });
                                                            numer =
                                                                List.generate(
                                                                    data.length,
                                                                    (index) =>
                                                                        false);
                                                            select =
                                                                List.generate(
                                                                    data.length,
                                                                    (index) =>
                                                                        0);
                                                            await checkData(
                                                                provider,
                                                                numer);
                                                            index = i;
                                                            data
                                                                .map((e) async {
                                                                  provider
                                                                      .Allcsv.map((d) => d[
                                                                          'Expression']
                                                                      .toString()
                                                                      .indexOf(
                                                                          e)).toList();
                                                                })
                                                                .toList()
                                                                .join()
                                                                .toString();
                                                            prevData = [];
                                                            for (int j = 0;
                                                                j < data.length;
                                                                j++) {
                                                              numer[j]
                                                                  ? {
                                                                      prevData.add(
                                                                          "[${font += 1}] ${data[j].toString()}")
                                                                    }
                                                                  : prevData
                                                                      .add(data[
                                                                              j]
                                                                          .toString());
                                                            }
                                                          },

                                                    // child main
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(10),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Text(
                                                                    "Pages ${(i + 1).toString()}"),
                                                                !click[i]
                                                                    ? ClipOval(
                                                                        child:
                                                                            Container(
                                                                          color: isSave[i]
                                                                              ? Colors.green
                                                                              : Colors.red,
                                                                          width:
                                                                              20,
                                                                          height:
                                                                              20,
                                                                        ),
                                                                      )
                                                                    : IconButton(
                                                                        onPressed:
                                                                            () async {
                                                                          // * เพิ่มค่า record
                                                                          await addRecord(
                                                                              provider: provider);
                                                                          // * บันทึกข้อมูล
                                                                          String
                                                                              raw =
                                                                              textResult.join().trim();
                                                                          String
                                                                              sendRaw =
                                                                              ('${prevData.map((e) => {
                                                                                    '"raw":"$e"'
                                                                                  }).toList()}');
                                                                          // ส่งไปserver
                                                                          await PdfApi().savePdf(
                                                                              u_id: pdfGet![i]['u_id'],
                                                                              raw: utf8.encode(raw).toString(),
                                                                              csv_id: provider.idCsv.toString(),
                                                                              rawSuggest: utf8.encode(sendRaw).toString());
                                                                          await getPdf(
                                                                              provider);
                                                                        },
                                                                        icon: const Icon(
                                                                            Icons.save))
                                                              ],
                                                            ),
                                                            click[i] &&
                                                                    i == index
                                                                ? Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      for (int j =
                                                                              0;
                                                                          j < data.length;
                                                                          j++)
                                                                        numer[j]
                                                                            ? openMenu(
                                                                                page: i,
                                                                                index: j,
                                                                                context: context,
                                                                                sug1: findValue(j)['Suggestion1'],
                                                                                sug2: findValue(j)['Suggestion2'],
                                                                                text: select[j] == 1
                                                                                    ? findValue(j)['Suggestion1']
                                                                                    : select[j] == 2
                                                                                        ? findValue(j)['Suggestion2']
                                                                                        : "[${font += 1}] ${data[j].toString()}")
                                                                            : Text(data[j].toString()),
                                                                      //  OpenMenu(),
                                                                    ],
                                                                  )
                                                                // ไฟล์ดิบ
                                                                : Text(
                                                                    "${pdfGet![i]['text']}"),
                                                          ],
                                                        )),
                                                  ),
                                                )
                                            ],
                                          )
                                        : const Text('')),
                              ),
                            ))
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
  }

  void dropDownProfessor(value, Store provider) async {
    setState(() {
      professor = value.toString();
    });
    room = null;
    roomSelect = [];
    var user = await listProfessor.firstWhere(
      (element) =>
          jsonDecode(element['data'])['name'].toString().trim() ==
          professor.toString().trim(),
      orElse: () => "-1",
    );
    IDprofessor = (user['u_id']);
    print(IDprofessor);
    user = (user['user'].toString().trim());
    var test = await Room().getAllRomm(user: user);
    if (test != "empty") {
      List a = test;
      List d = (test
          .map((element) => element['member']
              .toString()
              .split(",")
              .toList()
              .firstWhere(
                  (element) =>
                      element.toString().trim() ==
                      provider.userData['u_id'].toString().trim(),
                  orElse: () => "-1"))
          .toList());
      a
          .asMap()
          .entries
          .map((e) => d[e.key] == "-1"
              ? 2
              : roomSelect.add(RoomDropdownModel(
                  name: e.value['room_name'], room_id: e.value['u_id'])))
          .toList();
      setState(() {});
    } else {
      print("ว่าง");
    }
  }

  Future pickPdf() async {
    try {
      final pic = await FilePicker.platform
          .pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
      var res = pic!.files.first.bytes;
      Uint8List? base64 = res;
      pdf = base64Encode(base64!);
      setState(() {
        file = pic.files.first.bytes as List<int>;
        msg = pic.names.toString();
      });
    } catch (e) {
      return e;
    }
  }

  addRecord({required Store provider}) async {
    res.map((e) async {
      print(e);
      await CsvManage.updateRecord(updateAt: "e", u_id: e['u_id']);
      await CsvManage.recordType(
          name: e["Error type"], user_id: provider.userData['u_id']);
    }).toList();
    int indexRes = 0;
    for (i = 0; i < select.length; i++) {
      if (select[i] != 0) {
        // select[i] == 1
        //     ? CsvManage.updateRecord(updateAt: "s1", u_id: res[indexRes]["u_id"])
        //     : CsvManage.updateRecord(updateAt: "s2", u_id: res[indexRes]["u_id"]);
        switch (select[i]) {
          case 1:
            CsvManage.updateRecord(updateAt: "s1", u_id: res[indexRes]["u_id"]);
            break;
          case 2:
            CsvManage.updateRecord(updateAt: "s2", u_id: res[indexRes]["u_id"]);
            break;
          default:
        }
        indexRes += 1;
      }
    }
  }

  getPdf(Store provider) async {
    bool itEmpty = false;

    listProfessor = await Users().getProfessor();

    var respond = await PdfApi.getApiSelect(provider: provider);
    if (respond == "empty") {
      itEmpty = true;
    }
    List test = jsonDecode(respond);
    List newList = [], save = [];
    for (int i = 0; i < test.length; i++) {
      if (test[i]['text'][0] == "[") {
        String text = test[i]['text'].toString();
        List d = (text.substring(1, text.length - 1).split(","));
        List<int> eUtf8 = [];
        for (String a in d) {
          eUtf8.add(int.parse(a));
        }
        newList.add(test[i]);
        newList[i]['text'] = (utf8.decode(eUtf8));
        save.add(true);
      } else {
        newList.add(test[i]);
        save.add(false);
      }
    }

    // save zone
    isSave = save.reversed.toList();
    pdfGet = newList.reversed.toList();
    click = List.generate(pdfGet!.length, (index) => false);
    if (pdfGet!.isNotEmpty || itEmpty) {
      loaded = true;
      setState(() {
        check = false;
      });
    }
  }

  int l = 0;
  List textResult = [];
  openMenu(
      {required page,
      required sug1,
      required text,
      required sug2,
      required context,
      required index}) {
    setState(() {
      l++;
      for (int i = 0; i < numer.length; i++) {
        if (numer[index]) {
          textResult[index] = text;
        }
        if (!numer[i]) {
          textResult[i] = data[i];
        }
      }
    });
    return InkWell(
      onTap: () {
        final action = CupertinoActionSheet(
          title: const Text(
            "select Suggestion",
            style: TextStyle(fontSize: 30),
          ),
          actions: <Widget>[
            CupertinoActionSheetAction(
              onPressed: () {
                setState(() {
                  l = 0;
                  select[index] = 1;
                });
                Navigator.pop(
                  context,
                );
              },
              child: Text(sug1),
            ),
            if (sug2.isNotEmpty)
              CupertinoActionSheetAction(
                onPressed: () {
                  setState(() {
                    select[index] = 2;
                  });
                  Navigator.pop(context);
                },
                child: Text(sug2),
              ),
          ],
          cancelButton: CupertinoActionSheetAction(
            isDestructiveAction: true,
            onPressed: () {
              setState(() {
                select[index] = 0;
              });
              Navigator.pop(context);
            },
            child: const Text("Cancel"),
          ),
        );

        showCupertinoModalPopup(context: context, builder: (context) => action);
      },
      child: Text(
        text,
        style:
            TextStyle(color: select[index] != 0 ? Colors.green : Colors.amber),
      ),
    );
  }

  findValue(j) {
    print("data ${data[j]}");
    var result = res.firstWhere((element) =>
        element['Expressions'].toString().trim().toLowerCase() ==
        data[j].toString().trim().toLowerCase());
    return result;
  }
}

class RoomDropdownModel {
  RoomDropdownModel({required this.name, required this.room_id});
  final String name;
  final String room_id;
}
