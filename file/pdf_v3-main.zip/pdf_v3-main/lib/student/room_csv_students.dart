// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf_v3/student/select_pdf.dart';

import '../API/crude.dart';
import '../API/func.dart';

class RoomCsvStudents extends StatefulWidget {
  const RoomCsvStudents(
      {super.key, required this.roomData, required this.userProfessor});
  final String roomData;
  final String userProfessor;
  @override
  State<RoomCsvStudents> createState() => _RoomCsvStudentsState();
}

class _RoomCsvStudentsState extends State<RoomCsvStudents> {
  void getData() async {
    // TODO: this CSV
    csvFile = jsonDecode(await CsvApi.getApi(owner: widget.userProfessor));
    loading = false;
    setState(() {});
  }

  List csvFile = [];
  bool loading = true;
  @override
  Widget build(BuildContext context) {
    if (loading) {
      getData();
    }
    return Scaffold(
      appBar: AppBar(),
      body: csvFile.isEmpty
          ? Center(
              child: loading
                  ? const CircularProgressIndicator()
                  : const Text("No data"))
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 6),
              child: ListView.builder(
                itemCount: csvFile.length,
                itemBuilder: (context, index) => Card(
                    clipBehavior: Clip.antiAlias,
                    elevation: 2,
                    child: InkWell(
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectPDF(
                                    roomID: widget.roomData,
                                    name: csvFile[index]['name']
                                        .toString()
                                        .split(".")[0],
                                    category: csvFile[index]['name']
                                        .toString()
                                        .split(".")[0],
                                    user: widget.userProfessor,
                                  )
                              // ListStudents(
                              //     u_id: widget.roomData['u_id'].toString(),
                              //     category: csvFile[index]['name']
                              //         .toString()
                              //         .split(".")[0]),
                              )),
                      child: ListTile(
                        leading: Text(
                          csvFile[index]['name'].toString().split(".")[0],
                          style: const TextStyle(fontSize: 24),
                        ),
                      ),
                    )),
              ),
            ),
    );
  }
}
