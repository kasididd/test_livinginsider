// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf_v3/API/crude.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:pdf_v3/professor/widget/student_pdf.dart';
import 'package:pdf_v3/provider/store.dart';
import 'package:provider/provider.dart';

class ListProfessor extends StatefulWidget {
  const ListProfessor({
    super.key,
  });
  @override
  State<ListProfessor> createState() => _ListStudentsState();
}

class _ListStudentsState extends State<ListProfessor> {
  List listStudent = [],
      changName = [],
      nameController = <TextEditingController>[];
  List professor = [], select = [], listAdd = [], rawStudent = [];

  getProfessorSelected(Store provider) async {
    var l = jsonDecode(await Users().login(
            user: provider.userData['user'],
            password: provider.userData['password']))[0]['professor']
        .toString()
        .split(",")
        .toList();
    professor = await Users().getProfessor();
    select = List.generate(
        professor.length,
        (index) => l.firstWhere(
                  (element) =>
                      element.toString().trim() ==
                      professor[index]['u_id'].toString().trim(),
                  orElse: () => "-1",
                ) ==
                "-1"
            ? false
            : true);
    print(select);
    if (professor.isNotEmpty) {
      setState(() {
        if (professor[0] == "empty") {
          professor = [];
        }
        loading = false;
      });
    }
  }

  getCheckProfessor({required index, required Store provider}) async {
    select[index] = !select[index];
    List pID = [];
    select
        .asMap()
        .entries
        .map((e) => e.value ? pID.add(professor[e.key]['u_id']) : "")
        .toList();
    Room.AddProfessor(
        professorID: pID.toString().substring(1, pID.toString().length - 1),
        u_id: provider.userData['u_id']);
    setState(() {});
  }

  bool loading = true;
  @override
  Widget build(BuildContext context) {
    Store provider = context.watch<Store>();
    if (loading) {
      getProfessorSelected(provider);
    }
    return Scaffold(
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: Utility().phone(context)
                      ? 8
                      : Utility().size(context).width / 4),
              child: professor.isEmpty
                  ? const Center(
                      child: Text("No students..."),
                    )
                  : ListView.builder(
                      itemCount: professor.length,
                      itemBuilder: (context, index) => Card(
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                                onTap: () {
                                  getCheckProfessor(
                                      index: index, provider: provider);
                                },
                                child: ListTile(
                                  leading: Text(jsonDecode(
                                      professor[index]['data'])['name']),
                                  trailing: select[index]
                                      ? Icon(Icons.check)
                                      : Text(""),
                                )),
                          )),
            ),
    );
  }
}
