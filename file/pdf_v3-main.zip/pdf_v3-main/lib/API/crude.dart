// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:http/http.dart' as http;
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../provider/store.dart';

// const config = "192.168.135.32";
// mac
// const config = "localhost";
// const config = "192.168.197.217";

const config = "146.190.103.1";
// const config = "php";
const flask_config = "http://$config:5000";
// const link = "http://$config/pdf/backend/php.php";
const link = "http://$config:8000/backend/php.php";

class PdfApi {
  DESC({required String user, required String room_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "DESC",
        "table": "pdf_read",
        "user": user,
        "room_id": room_id
      });

      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        return data;
      }
    } catch (e) {
      return e.toString();
    }
  }

  commentInsert({required String comment, required String u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "comment",
        "table": "pdf_read",
        "comment": comment,
        "u_id": u_id
      });
      if (res.statusCode == 200) {
        return (res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  correctUpdate({required String correct, required String u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "correct",
        "table": "pdf_read",
        "correct": correct,
        "u_id": u_id
      });
      if (res.statusCode == 200) {
        return (res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  insertText({
    required String text,
    required String cate,
    required String user,
    required String room_id,
    required String IDprofessor,
  }) async {
    final url = Uri.parse(link);
    print("Inserting ");
    try {
      var res = await http.post(url, body: {
        "action": "insertText",
        "table": "pdf_read",
        "text": text,
        "cate": cate,
        "user": user,
        "room_id": room_id,
        "IDprofessor": IDprofessor
      });

      if (res.statusCode == 200) {
        return (res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static getApi() async {
    final url = Uri.parse(link);
    try {
      var res = await http
          .post(url, body: {"action": "GET_ALL", "table": "pdf_read"});

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static getApiSelect({required Store provider}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "SELECT",
        "table": "pdf_read",
        "user": provider.userData['user']
      });
      if (res.statusCode == 200) {
        return res.body.isEmpty ? "empty" : res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  getPdfStudent({required String user, required String category}) async {
    final url = Uri.parse(link);
    try {
      if (category.isEmpty) {
        var res = await http.post(url,
            body: {"action": "SELECT", "table": "pdf_read", "user": user});
        if (res.statusCode == 200) {
          return res.body.toString() == "[]" ? "empty" : res.body;
        }
      } else {
        var res = await http.post(url, body: {
          "action": "SelectCate",
          "table": "pdf_read",
          "user": user,
          "category": category
        });
        if (res.statusCode == 200) {
          return res.body.toString() == "[]" ? "empty" : res.body;
        }
      }
    } catch (e) {
      return e.toString();
    }
  }

  getPdfByRoomID(
      {required String user,
      required String category,
      required String roomID}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "getPdfByRoomID",
        "table": "pdf_read",
        "user": user,
        "roomID": roomID,
        "room_id": roomID,
        "category": category,
      });
      if (res.statusCode == 200) {
        return res.body.toString() == "[]" ? "empty" : res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static getApiSelectWidget({required user}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "SELECT", "table": "pdf_read", "user": user});
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  rawSuggest({
    required String u_id,
    required String rawSuggest,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "RawSuggest",
        "table": "pdf_read",
        "u_id": u_id,
        "RawSuggest": rawSuggest
      });
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  savePdf({
    required String u_id,
    required String rawSuggest,
    required String raw,
    required String csv_id,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "SavePDF",
        "table": "pdf_read",
        "u_id": u_id,
        "RawSuggest": rawSuggest,
        "raw": raw,
        "csv_id": csv_id
      });
      print(res.statusCode);
      if (res.statusCode == 200) {
        print(res.body);
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static testGet({required String u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "GET_JSON", "table": "pdf_read", "u_id": u_id});
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static uploadPdf({
    required pdf,
    required Store provider,
    required String category,
    required String room_id,
    required String IDprofessor,
  }) async {
    try {
      //  ? ส่งข้อมูล

      final url = Uri.parse("$flask_config/pdf");
      http.MultipartRequest request = http.MultipartRequest("POST", url);

      request.files
          .add(http.MultipartFile.fromBytes("pdf", pdf, filename: "new.pdf"));
      var status = await request.send();
      if (status.statusCode == 200) {
        var flask =
            await http.post(Uri.parse("$flask_config/uploadPdf"), body: {
          "user": provider.userData['user'],
          "category": category,
          "room": room_id,
          "IDprofessor": IDprofessor
        });
        if (flask.statusCode == 200) {
          print(flask.body);
          return flask.body;
        }
      }
    } catch (e) {
      print("$e");
      return e.toString();
    }
  }
}

class CsvApi {
  static getApi({required String owner}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "GET_ALL", "table": "csv_cate", "owner": owner});
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return "ไม่มีเน็ต";
    }
  }

  static deleteApi({required name}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "DELETE", "table": "csv_cate", "name": name});

      if (res.statusCode == 200) {
        print(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static uploadCsv({required csv, required name, required String owner}) async {
    final url = Uri.parse(link);
    try {
      final url = Uri.parse("$flask_config/csv");
      http.MultipartRequest request = new http.MultipartRequest("POST", url);

      request.files
          .add(http.MultipartFile.fromBytes("csv", csv, filename: "new.csv"));
      var status = await request.send();
      if (status.statusCode == 200) {
        var flask = await http.post(Uri.parse("$flask_config/uploadCsv"),
            body: {"name": name, "owner": owner});
        if (flask.statusCode == 200) {
          print(flask.body);
          return flask.body;
        }
      }
    } catch (e) {
      return e.toString();
    }
  }
}

class CsvManage {
  static updateRecord({required String updateAt, required String u_id}) async {
    final url = Uri.parse(link);
    dynamic update = updateAt == "e"
        ? {"action": "UpdateRecordE", "table": "csv_manage", "u_id": u_id}
        : updateAt == "s1"
            ? {"action": "UpdateRecordS1", "table": "csv_manage", "u_id": u_id}
            : {"action": "UpdateRecordS2", "table": "csv_manage", "u_id": u_id};
    try {
      var res = await http.post(url, body: update);
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static recordType({required String name, required String user_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "csv_manage",
        "action": "selectRecord",
        "name": name,
        "user_id": user_id,
      });
      if (res.statusCode == 200) {
        if (res.body != "found") {
          await http.post(url, body: {
            "table": "csv_manage",
            "action": "updateRecord",
            "name": name,
            "user_id": user_id
          });
        } else {
          await http.post(url, body: {
            "table": "csv_manage",
            "action": "addRecord",
            "name": name,
            "user_id": user_id
          });
        }
      }
    } catch (e) {
      return e.toString();
    }
  }

  getRecordType({required String user_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "csv_manage",
        "action": "getRecord",
        "user_id": user_id
      });
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static getApi({required String name}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "GET_ALL", "table": "csv_manage", "name": name});

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  getAllApi({required String owner}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url,
          body: {"action": "ALL", "table": "csv_manage", "owner": owner});

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  DESC({
    required String owner,
    required String name_csv,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "DESC",
        "table": "csv_manage",
        "owner": owner,
        "name": name_csv
      });

      if (res.statusCode == 200) {
        print("body : ${res.body}");
        return jsonDecode(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  ASC({
    required String owner,
    required String name_csv,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "ASC",
        "table": "csv_manage",
        "owner": owner,
        "name": name_csv
      });

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static deleteApi({required String name, required String owner}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "DELETE",
        "table": "csv_manage",
        "name": name,
        "owner": owner
      });

      if (res.statusCode == 200) {
        print(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static deleteById({required String name, required List u_id}) async {
    final url = Uri.parse(link);
    for (int i = 0; i < u_id.length; i++) {
      try {
        var res = await http.post(url, body: {
          "action": "DELETE_u_id",
          "table": "csv_manage",
          "name": name,
          "u_id": u_id[i]
        });

        if (res.statusCode == 200) {
          print(res.body);
        }
      } catch (e) {
        return e.toString();
      }
    }
  }

  InsertOne({
    required String name,
    required String Expressions,
    required String Suggestion1,
    required String Suggestion2,
    required String eRtype,
    required String owner,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "INSERT_ONE",
        "table": "csv_manage",
        "name": name,
        "Expressions": Expressions,
        "Suggestion1": Suggestion1,
        "Suggestion2": Suggestion2,
        "ERtype": eRtype,
        "owner": owner
      });

      if (res.statusCode == 200) {
        print(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static uploadCsv({required csv, required name}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {"csv": csv, "name": name});
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }
}

class Users {
  sendResetPassword({
    required String email_receiver,
    required String link,
  }) async {
    try {
      //  ? ส่งข้อมูล
      var flask = await http.post(Uri.parse("$flask_config/sendMail"),
          body: {"email_receiver": email_receiver, "link": link});
      if (flask.statusCode == 200) {
        print(flask.body);
        return flask.body;
      }
    } catch (e) {
      print("$e");
      return e.toString();
    }
  }

  login({required String user, required String password}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "SELECT",
        "table": "users",
        "user": user,
        "password": password
      });

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  getProfessor() async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "getProfessor",
        "table": "users",
      });
      if (res.statusCode == 200) {
        List data = jsonDecode(res.body);
        return data.isEmpty ? ["empty"] : data;
      }
    } catch (e) {
      return e.toString();
    }
  }

  getStudents({required Store provider}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "STUDENTS",
        "table": "users",
      });

      if (res.statusCode == 200) {
        List result = [];
        List data = jsonDecode(res.body);
        List itTrue = data
            .map(
                (e) => e['professor'].toString().split(",").toList().firstWhere(
                      (element) =>
                          element.toString().trim() ==
                          provider.userData['u_id'].toString().trim(),
                      orElse: () => "-1",
                    ))
            .toList();
        for (int i = 0; i < itTrue.length; i++) {
          if (itTrue[i] != "-1") {
            result.add(data[i]);
          }
        }
        return result;
      }
    } catch (e) {
      return e.toString();
    }
  }

  getMaster() async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "master",
        "table": "users",
      });

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  userData(provider) async {
    final url = Uri.parse(link);
    String user = await Usehive().auth("check", "");
    try {
      var res = await http.post(url, body: {
        "action": "USER_DATA",
        "table": "users",
        "user": user,
      });

      if (res.statusCode == 200) {
        print(res.body);
        await provider.getUser(data: res.body.toString().split("]")[0] + "]");
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  register({
    required String user,
    required String password,
    required String clas,
    required String data,
    required String professor,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "INSERT",
        "table": "users",
        "user": user,
        "password": password,
        "class": clas,
        "data": data,
        "professor": professor
      });

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  update({
    required String user,
    required String data,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "UPDATE",
        "table": "users",
        "user": user,
        "data": data,
      });

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  deleteUser({
    required String user,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "DELETE",
        "table": "users",
        "user": user,
      });

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  approve({
    required String user,
  }) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "APPROVE",
        "table": "users",
        "user": user,
      });

      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }
}

class Room {
  get({required user, required String csv_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "GET_ALL",
        "table": "room",
        "user": user,
        "csv_id": csv_id
      });
      if (res.statusCode == 200) {
        List data = jsonDecode(res.body);
        return data.isEmpty ? "empty" : data;
      }
    } catch (e) {
      return "empty";
    }
  }

  getAllRomm({required user}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "getAllRomm",
        "table": "room",
        "user": user,
      });
      if (res.statusCode == 200) {
        List data = jsonDecode(res.body);
        return res.body == "noData" ? ["empty"] : data;
      }
    } catch (e) {
      return "empty";
    }
  }

  getAllRommForStudents({required user, required String u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "action": "getAllRomm",
        "table": "room",
        "user": user,
      });
      if (res.statusCode == 200) {
        List data = jsonDecode(res.body);
        List select = data
            .map((e) => e['member'].toString().split(",").firstWhere(
                  (element) => element == u_id,
                  orElse: () => "-1",
                ))
            .toList();
        List send = [];
        data
            .asMap()
            .entries
            .map((e) => select[e.key] != '-1' ? send.add(e.value) : null)
            .toList();
        return send.isEmpty ? "empty" : send;
      }
    } catch (e) {
      return "empty";
    }
  }

  getMember({required u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http
          .post(url, body: {"action": "GET_ID", "table": "room", "u_id": u_id});
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return "ไม่มีเน็ต";
    }
  }

  static delete({required u_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http
          .post(url, body: {"action": "DELETE", "table": "room", "u_id": u_id});

      if (res.statusCode == 200) {
        print(res.body);
      }
    } catch (e) {
      return e.toString();
    }
  }

  static Insert({required user, required name, required String csv_id}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "room",
        "action": "INSERT_ONE",
        "room_name": name,
        "user": user,
        "csv_id": csv_id
      });
      print(res.statusCode);
      if (res.statusCode == 200) {
        print(res.body);
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static Update({required u_id, required name}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "room",
        "action": "UPDATE",
        "room_name": name,
        "u_id": u_id
      });
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static AddStudent({required u_id, required name}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "room",
        "action": "ADD_STUDENT",
        "room_name": name,
        "u_id": u_id
      });
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }

  static AddProfessor(
      {required String u_id, required String professorID}) async {
    final url = Uri.parse(link);
    try {
      var res = await http.post(url, body: {
        "table": "users",
        "action": "ADD_PROFESSSOR",
        "professor": professorID,
        "u_id": u_id
      });
      if (res.statusCode == 200) {
        return res.body;
      }
    } catch (e) {
      return e.toString();
    }
  }
}
