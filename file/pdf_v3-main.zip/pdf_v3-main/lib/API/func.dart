import 'package:flutter/cupertino.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';

import '../provider/store.dart';

class Func {
  convertSplit(
      {required String get,
      required Store provider,
      required String category,
      required String professor}) {
    List expression = provider.Allcsv;
    expression = (expression
        .where((element) =>
            element['name_csv'].toString().split(".")[0].toString().trim() ==
                category.toString().trim() &&
            element['owner'] == professor)
        .toList());
    print(expression);

    List start = [];
    List range = [];
    List idExpress = [];
    String sGet = get;
    int k = 0;
    expression.map((e) {
      int o =
          sGet.toLowerCase().indexOf(e['Expressions'].toString().toLowerCase());
      if (o != -1) {
        // if (!start.contains(o)) {
        start.add(o);
        range.add(e['Expressions'].length);
        idExpress.add(e['u_id']);
        // }
      }
      k++;
    }).toList();
    // ข้อมูลที่แยกมา
    provider.getIdCsv(data: idExpress.map((e) => e.toString().trim()).toList());

    k = 0;
    k = 0;
    List word = [];
    start
        .map((e) => {word.add(get.substring(e, (e + range[k]))), k++})
        .toList();
    List ag = get.split("");
    List output = [];
    for (String s in word) {
      int startC = ag.join().indexOf(s);
      int length = s.length;

      if (startC != -1) {
        ag.insert(startC, ";");
        ag.insert(startC + length + 1, ";");
      }
    }
    // for (String s in word) {
    //   int startC = ag.join().indexOf(s);
    //   int length = s.length;

    //   if (startC != -1 && ag[startC - 1] != ";") {
    //     ag.insert(startC, ";");
    //     ag.insert(startC + length + 1, ";");
    //   }
    //   x++;
    // }
    output = (ag.join().replaceAll("\n", "").split(";").toList());

    List cleanOutput = [];
    for (int i = 0; i < output.length; i++) {
      if (output[i].toString().length > 4) {
        cleanOutput.add(output[i]);
      }
    }
    // print(output);
    // print("range get: ${get.length}");
    // print("ag get: ${ag.length}");

    // print(output.join("\n"));
    // for (int e = 0; e < start.length * 2; e++) {
    //   e.isEven
    //       ? {ag.insert(start[x], ";"), x++}
    //       : ag.insert(start[x - 1] + range[x], ";");
    // }

    // old
    List data = get.toString().split("\n");
    String data2 = data.join();
    List data3 = [];
    for (int i = 0; i < data2.length; i++) {
      if (i > 0 && data2[i - 1] == " " && data2[i] != " ") {
        data3.add(" ");
      }
      if (data2[i] != " ") {
        data3.add(data2[i]);
      }
    }
    List data4 = data3.join().split(".");
    List data5 = [];
    data4.map((e) {
      if (e.toString().trim().isNotEmpty) {
        if ("." == e.trim()[e.trim().length - 1]) {
          data5.add(e.trim().substring(0, e.trim().length - 1));
        } else {
          data5.add(e.toString().trim());
        }
      }
    }).toList();
    return cleanOutput;
    // return ["s", "s"];
  }

  createPdf({required Store provider}) async {
    final doc = pw.Document();

    final ttf = await fontFromAssetBundle('assets/THSarabunNew.ttf');

    // for (int i = 0; i < 4; i++)
    for (int i = 0; i < provider.select_print.length; i++) {
      if (provider.select_print[i]) {
        doc.addPage(
          pw.Page(
            pageFormat: PdfPageFormat.a4,
            build: (pw.Context context) {
              return pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    pw.Text(provider.textPDF[i],
                        style: pw.TextStyle(font: ttf, fontSize: 18)),
                    if (provider.comments[i].text.toString().trim().isNotEmpty)
                      pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Container(
                                color: PdfColors.black,
                                width: double.infinity,
                                height: 1),
                            pw.Center(
                              child: pw.Text("comment",
                                  style: pw.TextStyle(font: ttf, fontSize: 18)),
                            ),
                            pw.SizedBox(
                              width: double.infinity,
                              child: pw.Text(provider.comments[i].text,
                                  style: pw.TextStyle(font: ttf, fontSize: 18)),
                            )
                          ])
                  ]); // Center
            },
          ),
        );
      }
    }
    await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => doc.save());
  }
}

class Utility {
  phone(context) {
    Size size = MediaQuery.of(context).size;
    return size.width < size.height;
  }

  Size size(context) {
    Size size = MediaQuery.of(context).size;
    return size;
  }
}

const String howToUse = '''
This program has been developed to assist students in improving their English composition. It provides feedback on first language transfer and grammar checking. The program offers two modes: student and teacher, with instructions for each mode as follows:


Student

1.	Register using your personal email and password.
2.	Wait for approval.
3.	Log in using your registration email and password.
4.	Choose the topic assigned by your teacher to submit your work.
5.	Inappropriate words/expressions will be highlighted for you to edit.
6.	Edited papers are automatically sent to your teacher.
7.	If you forget your login information, contact your teacher for assistance.

Teacher

1.	Register using your personal email and password.
2.	Wait for approval.
3.	Log in using your registration email and password.
4.	Check your students' written tasks and provide comments (If any).

''';
