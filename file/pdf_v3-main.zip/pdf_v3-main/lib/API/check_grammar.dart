import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:language_tool/language_tool.dart';
import 'package:pdf_v3/API/func.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import '../professor/widget/student_pdf.dart';

// class CheckGrammar extends StatelessWidget {
//   const CheckGrammar({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//           child: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: TextField(
//             onSubmitted: (value) => Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => CheckGrammar(data: value),
//                 )),
//           ),
//         ),
//       )),
//     );
//   }
// }

class CheckGrammar extends StatefulWidget {
  const CheckGrammar({super.key, required this.data});
  final String data;
  @override
  State<CheckGrammar> createState() => _MyHomeState();
}

class _MyHomeState extends State<CheckGrammar> {
  // ? หลังจากคำนวณเสร็จแล้วผลลัพธ์คือ
  String sentences = "";
  // ?ตั้งให้เป็นอังกฏษ
  final tool = LanguageTool(
    language: "en-US",
  );
// ! marker สีแดงคำผิด
  List outputMarker = [];
//  ! error ทั้งหมด
  List mistakeResult = [];
  funCheck({required String dataString}) async {
    var result = await tool.check(dataString);
    setState(() {
      mistakeResult = result;
    });
    List resultText = [];
    for (int i = 0; i < dataString.length; i++) {
      resultText.add(dataString[i]);
    }
    // check ทำเอง
    int count = 0;
    for (WritingMistake get in mistakeResult) {
      int start = get.offset + (count * 2);
      int length = get.length;
      resultText.insert(start, ";");
      resultText.insert(start + length + 1, ";");
      outputMarker = (resultText.join().split(";"));
      count++;
    }
    // ยืนยันการทำงานเสร็จสิ้น
    sentences = dataString;
  }

  @override
  void initState() {
    funCheck(dataString: widget.data);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("grammar check"),
        ),
        body: sentences.isEmpty
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : mistakeResult.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        sentences,
                        style: TextStyle(color: Colors.black),
                      ),
                    ),
                  )
                : isMistake());
  }

  SafeArea isMistake() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: SizedBox(
            width: Utility().phone(context)
                ? double.infinity
                : Utility().size(context).width / 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Card(
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => checkSentence(),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          RichText(
                            text: TextSpan(children: <TextSpan>[
                              for (int index = 0;
                                  index < outputMarker.length;
                                  index++)
                                (index.isEven)
                                    ? TextSpan(
                                        text: outputMarker[index],
                                        style: const TextStyle(
                                            color: Colors.black))
                                    : TextSpan(
                                        text: outputMarker[index],
                                        style: const TextStyle(
                                            color: Colors.red, fontSize: 18),
                                        // recognizer: TapGestureRecognizer()
                                        //   ..onTap = () {
                                        //     print("cleck");
                                        //   }
                                      )
                            ]),
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: Text(
                              "Click for detail ",
                              style: TextStyle(color: Colors.green),
                              textAlign: TextAlign.end,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

// ? details
  Column resultDetail(mistake) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        RichText(
          text: TextSpan(children: [
            const TextSpan(
                text: "Issue: ", style: TextStyle(color: Colors.red)),
            TextSpan(
                // ! แก้bug ภาษา Latin
                text: mistake.message.toString().replaceAll("â", " "),
                style: TextStyle(
                    fontFamily: GoogleFonts.patuaOne().fontFamily,
                    color: Colors.black)),
          ]),
        ),
        RichText(
          text: TextSpan(children: [
            const TextSpan(
                text: "IssueType: ", style: TextStyle(color: Colors.red)),
            TextSpan(
                text: mistake.issueDescription.toString(),
                style: const TextStyle(color: Colors.black)),
          ]),
        ),
        RichText(
          text: TextSpan(children: [
            const TextSpan(
                text: "positioned at: ", style: TextStyle(color: Colors.red)),
            TextSpan(
                text: mistake.offset.toString(),
                style: const TextStyle(color: Colors.black)),
          ]),
        ),
        RichText(
          text: TextSpan(children: [
            const TextSpan(
                text: "with the lengh of ",
                style: TextStyle(color: Colors.red)),
            TextSpan(
                text: mistake.length.toString(),
                style: const TextStyle(color: Colors.black)),
          ]),
        ),
        RichText(
          text: TextSpan(children: [
            const TextSpan(
                text: "Possible corrections: ",
                style: TextStyle(color: Colors.red)),
            TextSpan(
                text: "${mistake.replacements.toString()}\n",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: GoogleFonts.patuaOne().fontFamily,
                )),
          ]),
        ),
      ],
    );
  }

  checkSentence() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .8,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: SizedBox(
                width: 400,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // SizedBox(
                    //   width: double.infinity,
                    //   child: IconButton(
                    //       onPressed: () => _createPdf(title: {
                    //             "text": "hellohow are u",
                    //             "comment": "gell"
                    //           }),
                    //       icon: Icon(Icons.print)),
                    // ),
                    RichText(
                      text: TextSpan(children: <TextSpan>[
                        for (int index = 0;
                            index < outputMarker.length;
                            index++)
                          (index.isEven)
                              ? TextSpan(
                                  text: outputMarker[index],
                                  style: const TextStyle(color: Colors.black))
                              : TextSpan(
                                  text: outputMarker[index],
                                  style: const TextStyle(
                                      color: Colors.red, fontSize: 18),
                                )
                      ]),
                    ),
                    for (final mistake in mistakeResult) resultDetail(mistake),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _createPdf({required dynamic title}) async {
    final doc = pw.Document();
    String text = title['text'];
    String comment = title['comment'];
    final ttf = await fontFromAssetBundle('assets/THSarabunNew.ttf');

    // for (int i = 0; i < 4; i++)
    {
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            print(text);
            return pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  // for (int i = 0; i < 10; i++)
                  pw.Text(text, style: pw.TextStyle(font: ttf, fontSize: 18)),
                  if (comment.toString().trim().isNotEmpty)
                    pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Container(
                              color: PdfColors.black,
                              width: double.infinity,
                              height: 1),
                          pw.Center(
                              child: pw.Text("comment",
                                  style:
                                      pw.TextStyle(font: ttf, fontSize: 18))),
                          pw.SizedBox(
                            width: double.infinity,
                            child: pw.Text(comment,
                                style: pw.TextStyle(font: ttf, fontSize: 18)),
                          )
                        ])
                ]); // Center
          },
        ),
      );
    }
    await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => doc.save());
  }
}

// ? style
TextStyle kstyle = const TextStyle(
  decoration: TextDecoration.underline,
  decorationStyle: TextDecorationStyle.wavy,
  decorationColor: Colors.redAccent,
);
TextStyle kSuggeststyle = const TextStyle(
  decoration: TextDecoration.underline,
  decorationStyle: TextDecorationStyle.solid,
  decorationColor: Colors.green,
);
