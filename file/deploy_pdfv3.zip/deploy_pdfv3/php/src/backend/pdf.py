import sys
from PyPDF2 import PdfReader
import mysql.connector
from datetime import datetime
tUser = sys.argv[1]
mydb = mysql.connector.connect(
  host="db",
  user="root",
  password="BANANA",
  database="pdfdb"
)

open('lol.txt','w')
mycursor = mydb.cursor()

sql = 'INSERT INTO `pdf_read`(`u_id`, `text`, `page_id`, `time`,`user`,`RawSuggest`,`comment`) VALUES (null,"%s",%s,null,%s,0,0)'

file_name = "pdf/new.pdf"
reader = PdfReader(file_name)
ap = len(reader.pages)
for i in range(ap):
    val = (reader.pages[i].extract_text(), (f'{file_name} page:{i+1}'),tUser)
    if(len(val[0])>5):    
        mycursor.execute(sql, val)
    print(val[1])



mydb.commit()

print(mycursor.rowcount, "record inserted.")


