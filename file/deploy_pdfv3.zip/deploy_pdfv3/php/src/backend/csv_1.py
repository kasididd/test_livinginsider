import mysql.connector
import sys
import csv 
import json 
nameCsv = sys.argv[1]
# nameCsv = "test"

mydb = mysql.connector.connect(
  host="db",
  user="root",
  password="BANANA",
  database="pdfdb"
)




mycursor = mydb.cursor()

sql = "INSERT INTO `csv_manage`(`u_id`, `name_csv`, `Expressions`, `Suggestion1`, `Suggestion2`, `time`,`record_e`,`record_s1`,`record_s2`) VALUES (null,%s,%s,%s,%s,null,0,0,0)"

# for i in range(l):
#     reader = lines[i].split(",")
#     val = (nameCsv,reader[0], reader[1],reader[2])
#     if(len(reader[0])>3):    
#         mycursor.execute(sql, val)

def csv_to_json(csvFilePath, jsonFilePath):
    jsonArray = []
      
    #read csv file
    with open(csvFilePath, encoding='utf-8') as csvf: 
        csvReader = csv.DictReader(csvf) 
        for row in csvReader: 
            jsonArray.append(row)
    with open(jsonFilePath, 'w', encoding='utf-8') as jsonf: 
        jsonString = json.dumps(jsonArray, indent=4)
        jsonf.write(jsonString)
          
csvFilePath = r'data.csv'
jsonFilePath = r'data.json'
csv_to_json("csv/new.csv", "csv/test.json")
f = open("csv/test.json")
data = json.load(f)
for i in data:
    if len(i["Expressions/ words"])>3:
        val = (nameCsv,i["Expressions/ words"], i["Suggestion1"],i["Suggestion2"])
        mycursor.execute(sql, val)




mydb.commit()

print(mycursor.rowcount, "record inserted.")




  
