<?php
// echo "connection";

$conn =new mysqli("mysql","root","root","db");

// echo ($conn);
$output = $conn->query("SELECT * FROM studens");
// echo $result;
$query =  $conn->query("SELECT * FROM studens");
$result = array();
   while($rowData = $query->fetch_assoc()){
       $result[] = $rowData; 
}		
header('Content-Type: application/json');
      echo json_encode($result);