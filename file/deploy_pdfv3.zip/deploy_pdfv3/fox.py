import mysql.connector
from PyPDF2 import PdfReader
import csv 
import json 
mydb = mysql.connector.connect(
  host="mysql",
  user="root",
  password="root",
  database="pdfdb",
#   port="3306"
)

def uploadCsv(h):
    print(h)

    nameCsv = h
    mycursor = mydb.cursor()
    mycursor.execute(f'insert into csv_cate (`name`) values("{nameCsv}")')
    mydb.commit()

    sql = "INSERT INTO `csv_manage`(`name_csv`, `Expressions`, `Suggestion1`, `Suggestion2`, `record_e`,`record_s1`,`record_s2`) VALUES (%s,%s,%s,%s,0,0,0)"

    def csv_to_json(csvFilePath, jsonFilePath):
        jsonArray = []
        
        with open(csvFilePath, encoding='utf-8') as csvf: 
            csvReader = csv.DictReader(csvf) 
            for row in csvReader: 
                jsonArray.append(row)
        with open(jsonFilePath, 'w', encoding='utf-8') as jsonf: 
            jsonString = json.dumps(jsonArray, indent=4)
            jsonf.write(jsonString)
            
    csvFilePath = r'data.csv'
    jsonFilePath = r'data.json'
    csv_to_json("csv/new.csv", "csv/test.json")
    f = open("csv/test.json")
    data = json.load(f)
    len0 = "Expressions/ words"
    len1 = "Suggestion1"
    len2 = "Suggestion2"

    for i in data:
        if len(i[len0])>3:
            if i[len0][len(i[len0])-1]==".":
                i[len0] = i[len0].replace(i[len0][len(i[len0])-1],"")
                val = (nameCsv,i[len0], i[len1],i[len2])
                mycursor.execute(sql, val)
                print("ลบ จุด")
                mydb.commit()
                
            else:
                val = (nameCsv,i[len0], i[len1],i[len2])
                mycursor.execute(sql, val)
                print("ไมมีจุด")
                mydb.commit()
                




    print(mycursor.rowcount, "record inserted.")
    return ("success uploadCsv Flask")
    
def uploadPdf(h):
    tUser = h
    mycursor = mydb.cursor()

  

    file_name = "pdf/new.pdf"
    reader = PdfReader(file_name)
    ap = len(reader.pages)
    for i in range(ap):
        val = (reader.pages[i].extract_text(), (f'{file_name} page:{i+1}'),tUser)
        if(len(val[0])>5):    
            print (file_name)
            mycursor.execute(f'INSERT INTO `pdf_read`(`u_id`, `text`, `page_id`,  `user`, `RawSuggest`, `comment`) VALUES (null,"{reader.pages[0].extract_text()}","{file_name} page:{i+1}","{tUser}",0,"")')


    mydb.commit()

    print(mycursor.rowcount, "record inserted.")
    # return ("success uploadPdf Flask")
    return "output"




  
