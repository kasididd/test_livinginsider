from flask import Flask,request
from flask_cors import CORS
import fox
import os
from werkzeug.utils import secure_filename


app = Flask(__name__)
CORS(app)
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif','csv'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# อัปโหลดไฟล์
@app.route('/pdf', methods=['POST'])
def upload_file():
    UPLOAD_FOLDER = 'pdf'
    
    if request.method == 'POST':
        file = request.files['pdf']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, filename))
            return filename
    return ""

@app.route('/csv', methods=['POST'])
def upload_csv():
    UPLOAD_FOLDER = 'csv'
    
    if request.method == 'POST':
        file = request.files['csv']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, filename))
            return filename
    return ""



# upload_file
@app.route('/',methods=["POST","GET"])
def index():
    h = "new"
    l="v2"
    return l    

# uploadCsv
@app.route("/uploadCsv",methods=["POST"])
def uploadCsv():
    h = request.form["name"]
    response = fox.uploadCsv(h)
    return response
# uploadPdf
@app.route("/uploadPdf",methods=["POST"])
def uploadPdf():
    h = request.form["user"]
    response = fox.uploadPdf(h)
    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)